﻿using System;

namespace ConsoleApp0306
{
    class Program
    {

        public static bool EsPalindromo(int numero)
        {

            //TODO averiguar si es palíndromo número
            // 1. darle la vuelta a número 
            //       .- dividiendo entre 10 y concatenando las cifras en el orden inverso
            //       .- Conviertiendo el número a cadena y concatenando los componentes
            //          de la cadena( usando [] ) en orden inverso
            // 2.- Comparar los 2 números (el que está al derecho y el que está al revés) deben ser
            //      del mismo tipo ambos o los dos cadenas o los dos enteros.
            bool resultado;
            string numeroAlReves="";
            int numeroAlRevesEntero=0;
            int numeroOriginal = numero;
/*
            string numeroCadena = Convert.ToString(numero);
            string numeroCadenaAlReves = "";

            for(int i=numeroCadena.Length-1;i>=0;i--)
            {
                numeroCadenaAlReves = numeroCadenaAlReves + numeroCadena[i];
            }
    */        
            while(numero>0)
            {
                numeroAlReves = numeroAlReves+Convert.ToString(numero % 10);
                numero /= 10;
            }
            numeroAlRevesEntero = Convert.ToInt32(numeroAlReves);
            if (numeroAlRevesEntero == numeroOriginal)
                resultado = true;
            else
                resultado = false;
            return resultado;
        }

        public static bool EsPrimo(int numero)
        {
            bool resultado=true;

            for(int i=2;i<numero && resultado;i++)
            {
                if (numero % i == 0)
                    resultado = false;
            }

            return resultado;
        }
        public static bool EsPrimoPalindromo(int numero)
        {
            //   return (EsPrimo(numero) && EsPalindromo(numero));

            bool primo = EsPrimo(numero);
            bool palindromo = EsPalindromo(numero);
            return (primo && palindromo);
        }

        public static string QuitaEspacios(string cadena)
        {
            /* 4.	Realiza una función que reciba 
             * como parámetro una cadena a la que le deberá 
             * quitar todos los espacios. 
             * La función devolverá la cadena modificada
            */
            string resultado="";

            for (int i = 0; i < cadena.Length; i++)
            {
                if (cadena[i] != ' ')
                {
                    resultado += cadena[i];
                }
            }
            return resultado;
        }
        public static bool EsAlfabetico(char c)
        {
            return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
        }

        public static bool EsAlfabetico(string cadena)
        {
            bool esAlfabetico=true;
            /*
             * 10.	Vamos a realizar una función llamada 
             * EsAlfabetico que indique si una cadena es 
             * alfabética (Entre la A y la Z) o no. 
             * (Reutiliza la función anterior)
             * Se debe poder usar así:
             * if (EsAlfabetico("hola"))
             * */
            for(int i=0;i<cadena.Length && esAlfabetico;i++)
            {
                if (!EsAlfabetico(cadena[i]))
                {
                    esAlfabetico = false;
                }
            }
            return esAlfabetico;
        }



        static void Main(string[] args)
        {
            Console.WriteLine(EsPalindromo(121)?"Sí es palíndromo":"No es palíndromo");
            Console.WriteLine(EsPrimo(121) ? "Sí es primo" : "No es primo");
           Console.WriteLine(EsPrimoPalindromo(121) ? "Sí es primo y palíndromo" : "No es primo y palíndromo");
           Console.WriteLine(QuitaEspacios("Hola Mari Chelo"));
            Console.WriteLine(EsAlfabetico("Hola") ? "Sí es alfabetica" : "No es alfabetica");
        }
    }
}
