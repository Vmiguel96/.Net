﻿using System;
using System.IO;
using System.Text;

namespace Ficheros_binarios
{
    class Program
    {
        public static void EscribirBinario()
        {
            string archivo = "AppSettings.dat";
            using (BinaryWriter escritor = new BinaryWriter(File.Open(archivo, FileMode.OpenOrCreate)))
            {
                escritor.Write(1.2000);
                escritor.Write("MI CARRO ME LO ROBARON");
                escritor.Write(true);
                escritor.Write(1234);
            }
        }

        public static void LeerBinario()
        {
            string archivo = "AppSettings.dat";
            double a1;
            string a2;
            bool a3;
            int a4;
            using (BinaryReader lector = new BinaryReader(File.Open(archivo, FileMode.Open)))
            {
                a1 = lector.ReadDouble();
                a2 = lector.ReadString();
                a3 = lector.ReadBoolean();
                a4 = lector.ReadInt32();
            }

            Console.WriteLine($"{a1}-{a2}-{a3}-{a4}");
        }

        public static void LeerAleatorio()
        {

            try
            {
                FileStream fichero = File.OpenRead("H.exe");
                if (fichero.Length > 30)
                {
                    fichero.Seek(3, SeekOrigin.Begin);
                    int nuevoDato = fichero.ReadByte();
                    Console.WriteLine("El byte 20 es un {0}", (char)nuevoDato);
                    Console.WriteLine("La posición actual es {0}", fichero.Position);
                    nuevoDato = fichero.ReadByte();
                    Console.WriteLine("El byte 20 es un {0}", (char)nuevoDato);
                }
                fichero.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }


        }


        public static void LeerMP3()
        {
            const int TAG = 3;
            const int TITULO = 30;
            const int ARTISTA = 30;
            const int ALBUM = 30;
            const int ANYO = 4;
            const int COMENTARIO = 30;
            const int GENERO = 1;

            byte[] tag = new byte[TAG];
            byte[] titulo = new byte[TITULO];
            byte[] artista = new byte[ARTISTA];
            byte[] album = new byte[ALBUM];
            byte[] anyo = new byte[ANYO];
            byte[] comentario = new byte[COMENTARIO];
            byte[] genero = new byte[GENERO];

            string archivoMp3 = "input.mp3";
            using (FileStream archivo = File.OpenRead(archivoMp3))
            {
                archivo.Seek(-128, SeekOrigin.End);
                archivo.Read(tag, 0, TAG);
                archivo.Read(titulo, 0, TITULO);
                archivo.Read(artista, 0, ARTISTA);
                archivo.Read(album, 0, ALBUM);
                archivo.Read(anyo, 0, ANYO);
                archivo.Read(comentario, 0, COMENTARIO);
                archivo.Read(genero, 0, GENERO);
            }

            Console.WriteLine($"{Encoding.Default.GetString(tag)}");
            Console.WriteLine($"{Encoding.Default.GetString(titulo)}");
            Console.WriteLine($"{Encoding.Default.GetString(artista)}");
            Console.WriteLine($"{Encoding.Default.GetString(album)}");
            Console.WriteLine($"{Encoding.Default.GetString(anyo)}");
            Console.WriteLine($"{Encoding.Default.GetString(comentario)}");
            int generoNumero = genero[0];
            Console.WriteLine($"{generoNumero}");
            
        }

        public static void LeerBMP()
        {
            const int ALTO = 4;
            const int ANCHO = 4;
            byte[] alto = new byte[ALTO];
            byte[] ancho = new byte[ANCHO];


            string archivoBMP = "logo.bmp";
            using (FileStream archivo = File.OpenRead(archivoBMP))
            {
                archivo.Seek(18, SeekOrigin.Begin);
                archivo.Read(alto, 0, ALTO);
                archivo.Read(ancho, 0, ANCHO);
            }
            int altoN = alto[0] + (alto[1] * 256) + (alto[2]* (256*256)) + (alto[3] * (256*256*256));
            int anchoN = ancho[0] + ancho[1]*256 + ancho[2]* 256*256 + ancho[3]*256*256*256;
            Console.WriteLine($"{(int) alto[0]}x{(int)alto[1]}x{(int) alto[2]}x{(int)alto[3]} = {altoN}");
            Console.WriteLine($"{(int)ancho[0]}x{(int)ancho[1]}x{(int)ancho[2]}x{(int)ancho[3]} = {anchoN}");
        }

        static void Main(string[] args)
        {
            //EscribirBinario();
            // LeerBinario();
            //LeerAleatorio();
            //LeerMP3();
            LeerBMP();
        }
    }
}
