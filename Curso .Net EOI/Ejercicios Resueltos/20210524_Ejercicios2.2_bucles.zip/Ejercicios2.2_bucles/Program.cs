﻿using System;

namespace Ejercicios2._2_bucles
{
    class Program
    {
        static void Main(string[] args)
        {

            // EJERCICIO 8
            //string usuario, password;
            //int intentoFallido = 0;
            //do
            //{ 
            //    Console.Write("Introduce el Usuario:");
            //    usuario=Console.ReadLine();
            //    Console.Write("Introduce la contraseña:");
            //    password = Console.ReadLine();
            //    if (!(usuario == "1" && password.Equals("1234")))
            //    { 
            //        intentoFallido++; 
            //    }

            //}
            //while (!(usuario == "1" && password.Equals("1234")) && intentoFallido < 3);

            //if (intentoFallido == 3)
            //{
            //    Console.WriteLine("Ha superado el número de intentos permitidos.");
            //}
            //else
            //{
            //  Console.Write($"Acceso permitido{usuario}. Contador de intentos:{intentoFallido}");
            //}

            // EJERCICIO 9
            //int numero = 0, contador = 1 ;
            //Console.Write($"Introduce un número:");
            //numero = Convert.ToInt32(Console.ReadLine());
            //while (contador<=numero) // LOS PARES
            //{
            //    if (contador % 2 == 0)
            //    {
            //        if (contador < numero) // ESTE IF ES PARA DEJAR BONITA LA SALIDA POR PANTALLA
            //            Console.Write($"{contador}, ");
            //        else
            //            Console.Write($"{contador}\n");
            //    }
            //    contador++;
            //}
            //contador = 1;

            //while (contador <= numero) // PARA PODER IR DE 3 EN 3
            //{
            //    if (contador % 3 == 0)
            //    {
            //        if (contador < numero) // ESTE IF ES PARA DEJAR BONITA LA SALIDA POR PANTALLA
            //            Console.Write($"{contador}, ");
            //        else
            //            Console.Write($"{contador}\n");
            //    }
            //    contador++;
            //}

            // EJERCICIO 10
            //int numero = 0, contador = 1 ;
            //int pares = 0, impares = 0;
            //Console.Write($"Introduce un número:");
            //numero = Convert.ToInt32(Console.ReadLine());
            //while (contador <= numero)
            //{
            //    if (contador % 2 == 0)
            //        pares++;
            //    else
            //        impares++;

            //    contador++;
            //}
            //Console.WriteLine($"El número de pares es:{pares}\nEl número de impares es:{impares}");

            // EJERCICIO 11
            //int numero = 0, contador = 1;
           
            //Console.Write($"Introduce un número:");
            //numero = Convert.ToInt32(Console.ReadLine());

            //while (contador <= numero)
            //{
            //    Console.WriteLine($"El cuadrado de {contador} es {contador * contador}"); //Math.Pow(contador,2)
            //    contador++;
            //}
                     
            
            // JUEGO
            // Crea una juego que genere un número aleatorio (1-10) y que nos dé 5 oportinidades para poder adivinarlo.
            // Si lo adivinamos antes de  los 5 intentos nos felicitará y si por el contrario no los conseguimos
            // nos informará que hemos perdido y del número correcto.
           // int adivina = new Random().Next()%10 + 1;// nos genera un núemero aleatorio 1-10

            // 1. GENERAR EL NUMERO
            // 2. PEDIR NUMEROS AL USUARIO
            // 3. REPETIR HASTA (GANE o SUPERE LOS 5 INTENTOS)
            //     3.1 COMPROBACION DEL CONCURSO
            //     3.2 AUMENTAR LOS FALLOS EN CASO DE QUE CORRESPONDA
            // 4. RESULTADO (GANA o PIERDE)

            //int adivina = new Random().Next() % 10 + 1;// nos genera un núemero aleatorio 1-10
            //int numero = 0;
            //int intentos = 0;
            //bool ganador = false;
            //do
            //{
            //    Console.Write($"Introduce un número:");
            //    numero = Convert.ToInt32(Console.ReadLine());
            //    if (numero == adivina)
            //    {
            //        ganador = true;
            //    }
            //    else 
            //    {
            //        intentos++;
            //    }
            //} 
            //while (intentos < 5 && ganador == false);
            //if (ganador)
            //    Console.WriteLine($"ENHORABUENA has ganado al número secreto");
            //else
            //    Console.WriteLine($"GAME OVER. El número secreto era:{adivina}");


            // JUEGO PRO
            // Crea una juego que genere un número aleatorio (1-100) y que nos dé 5 oportinidades para poder adivinarlo.
            // Si lo adivinamos antes de  los 5 intentos nos felicitará y si por el contrario no los conseguimos
            // nos informará que hemos perdido y del número correcto.
            // El juego nos informará con frío o caliente si estamos cerca del número (+- 5 números)
            // int adivina = new Random().Next()%100 + 1;// nos genera un núemero aleatorio 1-100

            int adivina = new Random().Next() % 100 + 1;// nos genera un núemero aleatorio 1-10
            int numero = 0;
            int intentos = 0;
            bool ganador = false;
            do
            {
                Console.Write($"Introduce un número:");
                numero = Convert.ToInt32(Console.ReadLine());
                if (numero == adivina)
                {
                    ganador = true;
                }
                else
                {
                    if (numero >= adivina -5 && numero <= adivina + 5)
                    {
                        // CALIENTE
                        Console.WriteLine($"El número {numero} está CALIENTE.");
                    }
                    else
                    {
                        //FRIO
                        Console.WriteLine($"El número {numero} está FRIO.");
                    }
                    intentos++;
                }
            }
            while (intentos < 5 && ganador == false);
            if (ganador)
                Console.WriteLine($"ENHORABUENA has ganado al número secreto");
            else
                Console.WriteLine($"GAME OVER. El número secreto era:{adivina}");
        }
    }
}
