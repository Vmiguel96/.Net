﻿using System;

namespace ConsoleApp6
{
    class Program
    {
        static void Main(string[] args)
        {
            // EXPLICACIÓN 17/05
            //Nota: esto sirve para imprimir por pantalla
            /* Esto es un comentario de varias líneas
             líenas 2 * /
             línea3 */
            //double resultadoDivision = 2.5;
            //float resultadoDiv = 2.5f;
            //int resultadoSuma = 35;
            //char letraA = 'a';
            //string palabraCompleta = "HOLA MUNDO";
            //bool respuesta_1 = false; // true
            //int n1=0, n2=2, n3=0;

            //Console.WriteLine("Hola, Soy Antonio Rodríguez");
            // EJERCICIO 1
            //int n1 = 36;
            //int n2 = 27;
            //int resultado;
            //resultado = n1 + n2;
            // 
            //Console.WriteLine(36+27);


            // EJERCICIO 2
            //int num1 = 15;
            //int num2 = 4;
            //int resultadoSuma;
            //int resultadoResta;
            //int resultadoMulti;
            //double resultadoDivision;
            //int resultadoResto;

            //Console.WriteLine("Resultados 2.A");
            //// 2.A
            //Console.WriteLine("15+4 = " + (num1 + num2));
            //Console.WriteLine("15-4 = " + (num1 - num2));
            //Console.WriteLine("15/4 = " + (num1 / num2)); // No salen los decimales
            //Console.WriteLine("15*4 = " + (num1 * num2));
            //Console.WriteLine("15%4 = " + (num1 % num2));
            //// 2.B

            //Console.WriteLine("Resultados 2.B");
            //resultadoSuma = num1 + num2;
            //resultadoResta = num1 - num2;
            //resultadoDivision = num1 / num2;
            //resultadoMulti = num1 * num2;
            //resultadoResto = num1 % num2;
            //Console.WriteLine("15+4 = " + resultadoSuma);
            //Console.WriteLine("15+4 = " + resultadoSuma);
            //Console.WriteLine("15-4 = " + resultadoResta);
            //Console.WriteLine("15/4 = " + resultadoDivision); // No salen los decimales
            //Console.WriteLine("15*4 = " + resultadoMulti);
            //Console.WriteLine("15%4 = " + resultadoResto);

            // const double PI = 3.141592;
            //Console.WriteLine('m' - 'a');
            //Console.WriteLine("Hola:" + "MUNDO");

            //string nombre = "Verónica";
            //int edad = 18; 
            //Console.WriteLine(nombre + " tiene " + edad + " años");

            //// EJERCICIO 6
            //int A = 1;
            //int B = 2;
            //int C = 3;
            //int D = 4;
            //int originalA, originalB, originalC, originalD;
            //originalA = A;
            //originalB = B;
            //originalC = C;
            //originalD = D;
            //Console.WriteLine($"Valores originales:A={A}, B={B}, C={C}, D={D}");
            //B = originalC;
            //C = originalA;
            //A = originalD;
            //D = originalB;
            //Console.WriteLine($"Valores Modificados:A={A}, B={B}, C={C}, D={D}");
            // EJERCICIO 7
            //char caracter1 = 'b';
            //char caracater2 = 'k';
            //Console.WriteLine($"El caracater {caracter1} tiene el valor {(int) caracter1}");
            //Console.WriteLine($"El caracater {caracater2} tiene el valor {(int) caracater2}");
            //Console.WriteLine($"La diferencia entrea {caracater2} y {caracter1} es {(int)caracater2 - (int)caracter1}");
            //EJERCICIO 8

            //int a = 5;
            //int b = 0;
            //int c = 0;

            //b = ++a;
            //Console.WriteLine($"valor de b:{b}");
            //c = a++;
            ////a++ ==> a = a + 1;
            ////a-- ==> a = a - 1;
            //Console.WriteLine($"valor de c:{c}");
            //b = b * 5;
            //Console.WriteLine($"Valor de b:{b}");
            //a = a * 2;
            //Console.WriteLine($"valor de a:{a}");

            //double potencia = 0;
            //potencia =  Math.Pow(2, 3);
            //Console.WriteLine($"Potencia 2^3:{potencia}");

            //Console.WriteLine("Hola"); 
            //Console.WriteLine("Mundo");
            //Console.Write("Hola"); 
            //Console.Write("Mundo")

            //Console.Write("Hola\nMundo");

            //Console.WriteLine("Elige una opción"); 
            //Console.WriteLine("\t1) Añadir producto");
            //Console.WriteLine("\t\t1.1) Añadir melones");
            //Console.WriteLine("\t\t1.2) Añadir melocotones");
            //Console.WriteLine("\t2) Borrar producto");
            //Console.WriteLine("\t\t2.1) Borrar Melones");
            //Console.WriteLine("\t\t2.2) Borrar Melocotones");
            //Console.WriteLine("fin");

            //string nombre1 = "Paco";
            //string nombre2 = "Anastasia";
            //double salario1 = 20300.247;
            //double salario2 = 24439.6;
            //Console.WriteLine($"{"NOMBRE",12}{"SALARIO",14}"); 
            //Console.WriteLine($"---------------------------");
            //Console.WriteLine($"{nombre1,12}{salario1,14:C2}"); 
            //Console.WriteLine($"{nombre2,12}{salario2,14:C2}");

            //int dia = 4; 
            //int mes = 6; 
            //int anyo = 2013; 
            //Console.WriteLine($"Fecha: {dia:D3}/{mes:D3}/{anyo:D7}");

            Console.WriteLine("Dime tu nombre: "); 
            string nombre = Console.ReadLine(); 
            System.Console.WriteLine($"Hola {nombre}"); //Dime tu nombre: Arturo ← Escrito por el usuarioHola Arturo
            //Console.WriteLine("Presiona una tecla");
            //var tecla = Console.ReadKey(true); 
            // No muestra la tecla pulsadaSystem.Console.WriteLine($"Tecla pulsada: {tecla.KeyChar}");Presiona una teclaTecla pulsada: d
        }
    }
}
