﻿using System;

namespace _1._3_ArraysBidimensionales
{
    class Program
    {

        public static void Ejercicio1()
        {
            string[] nombres = new string[10];
            string nombreTemp = "";
            bool encotrado = false;
            for (int i = 0; i < nombres.Length; i++)
            {
                Console.Write("Introduce un nombre:");
                nombreTemp = Console.ReadLine();
                // COMPROBAR SI EL NOMBRE EXISTE SOLO SIRVE PARA BUSCAR
                // for (int j = 0; j<nombres.Length;j++)
                for (int j = 0; j < i && !encotrado; j++) // VERSION OPTIMIZADA
                {
                    if (nombreTemp == nombres[j])
                    {
                        // YA EXISTE ESE NOMBRE
                        encotrado = true;
                        Console.WriteLine($"El nombre {nombreTemp} ya existe.");
                    }
                }

                if (encotrado == true)
                {
                    i--;
                }
                else
                {
                    nombres[i] = nombreTemp;
                }
                encotrado = false;
            }


            for (int i = 0; i < nombres.Length; i++)
            {
                Console.WriteLine($"{nombres[i]}");
            }

        }

        public static void Ejercicio2()
        {
            string nombre = "";
            int numVocales = 0;
            Console.Write("Introduce un nombre:");
            nombre = Console.ReadLine();
            nombre = nombre.ToLower();
            for (int i = 0; i < nombre.Length; i++)
            {
                if (nombre[i] == 'a' || nombre[i] == 'e' || nombre[i] == 'i' || nombre[i] == 'o' || nombre[i] == 'u')
                    numVocales++;
            }

            Console.WriteLine($"En la palabra {nombre} hay {numVocales}");
            Console.ReadKey();

        }

        public static void Ejercicio4()
        {
            string[] alumnos = { "Sara", "Eduardo", "Emilio","Carmen" };
            double[,] notas ={
                                {5,6.5,7,3.99},
                                {4,3,4.5,7},
                                {6.6,7.4,9,10},
                                {2.75,6,8,9 }
                              };
            for(int i = 0; i<notas.GetLength(0);i++)
            {
                double media = 0;
                for (int j = 0; j < notas.GetLength(1); j++)
                {
                    media = media + notas[i,j];
                }
                Console.WriteLine($"La media de {alumnos[i]} es {media/notas.GetLength(1):F2}");
            }

        }


        public static void Ejercicio5()
        {
            string[] alumnos;
            double[,] notas;
            int numAlumno = 0;
            int numNotas = 0;

            Console.WriteLine("¿Cuantos alumnos vas a introducir?");
            numAlumno= Convert.ToInt32( Console.ReadLine());

            alumnos = new string[numAlumno];
            Console.WriteLine("¿Cuantos notas va a tener cada alumno?");
            numNotas = Convert.ToInt32(Console.ReadLine());
            notas = new double[numAlumno, numNotas];
            //PARTE DEL CÖDIGO PARA PEDIR NOMBRE Y NOTAS
            for (int i = 0; i < notas.GetLength(0); i++)
            {
                Console.WriteLine("Introduce el nombre del alumno:");
                alumnos[i] = Console.ReadLine();
                for (int j = 0; j < notas.GetLength(1); j++)
                {
                    Console.WriteLine($"Introduce la nota {j+1}");
                    notas[i, j] = Convert.ToDouble(Console.ReadLine());
                }
  
            }


            for (int i = 0; i < notas.GetLength(0); i++)
            {
                double media = 0;
                for (int j = 0; j < notas.GetLength(1); j++)
                {
                    media = media + notas[i, j];
                }
                Console.WriteLine($"La media de {alumnos[i]} es {media / notas.GetLength(1):F2}");
            }

        }
        static void Main(string[] args)
        {

            //if (args.Length == 2)
            //{
            //    if (args[0] == "antonio" && args[1] == "1234")
            //      Console.WriteLine($"Bienvenidos al progrma Xxx 2.0");
            //}
            //else 
            //{
            //    Console.WriteLine("Error: el programa necesita dos parámetros.");
            //}
            
            //Console.ReadKey();
            //Console.WriteLine($"He recibido {args.Length} parámetros: ");
            //foreach (string param in args)
            //{
            //    Console.WriteLine(param);
            //}
            //Ejercicio1();
            // Ejercicio2();
            Ejercicio4();
        }
    }
}
