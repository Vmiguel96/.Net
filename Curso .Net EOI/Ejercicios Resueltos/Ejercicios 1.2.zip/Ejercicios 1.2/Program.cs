﻿using System;

namespace Ejercicios_1._2
{
    class Program
    {
        static void Main(string[] args)
        {
            //EJERCICIO 1
            //string nombre;
            //Console.WriteLine("Hola ¿Cómo te llamas?");
            //nombre = Console.ReadLine();
            //Console.WriteLine($"Hola {nombre}");

            // EJERCICIO 2
            //Console.Write("Introduzca un número:");
            //int numero;
            //numero = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine($"El doble de {numero} es {numero * 2}");
            //Console.WriteLine($"El triple de  {numero} es {numero * 3}");
            //Console.WriteLine($"El cuadrado de  {numero} es {Math.Pow(numero, 2)}");
            //Console.WriteLine($"El cubo de  {numero} es {Math.Pow(numero, 3)}");
            //Console.WriteLine($"El raíz cuadrada de  {numero} es {Math.Sqrt(numero)}");

            // EJERCICIO 3
            //string grados;
            //double numeroGrados;
            //double resultado;
            //Console.Write("Introduzca los grados centígrados:");
            //grados=Console.ReadLine();
            //numeroGrados = Convert.ToDouble(grados);
            //resultado = 32 + (9 * numeroGrados / 5);
            //Console.WriteLine($"{numeroGrados}º centígrados son {resultado:F2}º Farenheit");

            //EJERCICIO 4
            //int numero, centenas, decenas, unidades, auxiliar;
            //Console.Write("Introduce un número de 3 dígitos:");
            //numero = Convert.ToInt32(Console.ReadLine());
            //// 543 --> 5 --> 4 --> 3
            ////543/10 = 54
            ////543%10 = 3
            ////-----------------
            ////54/10 = 5
            ////54%10 = 4
            ////-------------------
            //auxiliar = numero / 10;
            //unidades = numero % 10;
            ////---------------------
            //centenas = auxiliar / 10;
            //decenas = auxiliar % 10;
            //// -------------------
            //Console.WriteLine($"Centenas:{centenas}");
            //Console.WriteLine($"Decenas:{decenas}");
            //Console.WriteLine($"Unidades:{unidades}");

            // EJERCICIO 5
            //int dia, mes, anyo, suma;
            //int miles, centenas, decenas, unidades, auxiliar;
            //Console.Write("Introduce el día de tu nacimiento:");
            //dia = Convert.ToInt32(Console.ReadLine());
            //Console.Write("Introduce el mes de tu nacimiento:");
            //mes = Convert.ToInt32(Console.ReadLine());
            //Console.Write("Introduce el año de tu nacimiento:");
            //anyo = Convert.ToInt32(Console.ReadLine());

            //suma = dia + mes + anyo;// asumimos máximo valor 9999

            //unidades = suma % 10;
            //auxiliar = suma / 10;
            ////--------------------
            //decenas = auxiliar % 10;
            //auxiliar = auxiliar / 10;
            ////----------------------
            //centenas = auxiliar % 10;
            //miles = auxiliar / 10;
            //// Se pone para comprobar el resultado de los cálculos obtenidos
            //Console.WriteLine($"suma:{suma} valores:{miles},{centenas},{decenas},{unidades}");
            //Console.WriteLine($"Tu número de la suerte es:{miles+ centenas+ decenas + unidades }");

            //EJERCICIO 6
            // Muy sencillo

            // EJERCICIO 7
            string articulo1, articulo2, articulo3;
            double precio1, precio2, precio3;

            Console.Write("Introduzca el primer artículo:");
            articulo1 = Console.ReadLine();
            Console.Write("Introduzca el precio del primer artículo:");
            precio1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Introduzca el segundo artículo:");
            articulo2 = Console.ReadLine();
            Console.Write("Introduzca el precio del segundo artículo:");
            precio2 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Introduzca el tercer artículo:");
            articulo3 = Console.ReadLine();
            Console.Write("Introduzca el precio del tercer artículo:");
            precio3 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine($"{"NOMBRE",-15}{"PRECIO",12}{"CON IVA",12}");
            Console.WriteLine($"{articulo1,-15}{precio1,12:C2}{precio1 * 1.21,12:C2}");
            Console.WriteLine($"{articulo2,-15}{precio2,12:C2}{precio2 * 1.21,12:C2}");
            Console.WriteLine($"{articulo3,-15}{precio3,12:C2}{precio3 * 1.21,12:C2}");
        }
        }
}
