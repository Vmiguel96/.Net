﻿using System;

namespace ConsoleApp0106
{
    class Program
    {

        public static void Ejercicios1y2()
        {
            //Ejercicios 1 y 2
            double media = 0, suma = 0;
            int notas;
            //declarar un array y reservar memoria en una sola línea
            //  int[] numeros = new int[10];

            //declarar el array y reserva de memoria en 2 líneas
            int[] numeros;

            Console.Write("Cuantas notas ?");
            notas = Convert.ToInt32(Console.ReadLine());
            numeros = new int[notas];

            for (int i = 0; i < numeros.Length; i++)
            {
                Console.Write($"Introduzca el número {i + 1}: ");
                numeros[i] = Convert.ToInt32(Console.ReadLine());
                suma += numeros[i];
            }
            media = suma / numeros.Length;
            Console.WriteLine(media);
            Console.WriteLine("Números por encima de la media:");
            for (int i = 0; i < numeros.Length; i++)
            {
                if (numeros[i] > media)
                {
                    Console.WriteLine(numeros[i]);
                }
            }


        }

        public static void Ejercicio3()
        {
            int[] numeros=new int[10];
            int[] pares;
            int[] impares;
            int cuentaPares = 0, cuentaImpares = 0;

            for (int i = 0; i < numeros.Length; i++)
            {
                Console.Write($"Introduzca el número {i + 1}: ");
                numeros[i] = Convert.ToInt32(Console.ReadLine());
                if(numeros[i]%2==0)
                {
                    cuentaPares++;
                }
                else
                {
                    cuentaImpares++;
                }
            }

            pares = new int[cuentaPares];
            impares = new int[cuentaImpares];
            int indicePares = 0;
            int indiceImpares = 0;

            for(int i=0;i<numeros.Length;i++)
            {
                if(numeros[i]%2==0)
                {
                    pares[indicePares] = numeros[i];
                    indicePares++;
                }
                else
                {
                    impares[indiceImpares] = numeros[i];
                    indiceImpares++;
                }
            }
            for(int i=0;i<pares.Length;i++)
            {
                Console.WriteLine(pares[i]);
            }
            for (int i = 0; i < impares.Length; i++)
            {
                Console.WriteLine(impares[i]);
            }

        }

        public static void Ejercicio4()
        {
            int[] numeros = new int[11];

            for (int i = 0; i < numeros.Length; i++)
            {
                Console.Write($"Introduzca el número {i + 1}: ");
                numeros[i] = Convert.ToInt32(Console.ReadLine());
            }

            Array.Sort(numeros);

            Console.WriteLine($"El número mínimo es: {numeros[0]}");
            Console.WriteLine($"El número máximo es: {numeros[numeros.Length - 1]}");
            Console.WriteLine($"La mediana es: {numeros[numeros.Length / 2]}");


        }

        public static void Ejercicio5()
        {
            string nombre;

            Console.Write("Escriba un nombre: ");
            nombre = Console.ReadLine();

            for(int fila=0;fila<nombre.Length;fila++)
            {
                for(int columna=0;columna<=fila;columna++)
                {
                    Console.Write(nombre[columna]);
                }
                Console.WriteLine();
            }
        }

        public static void Barquitos()
        {
            const int MAXIMO=10;
            Random r = new Random();
            int coordenadaI, coordenadaJ;

            char[,] tablero = new char[MAXIMO, MAXIMO];

            for(int i=0;i<MAXIMO;i++)
            {
                for(int j=0;j<MAXIMO;j++)
                {
                    tablero[i, j] = 'a';
                }
            }
            int barcos = 0;
            while(barcos<10)
            {
                coordenadaI = r.Next(0, MAXIMO);
                coordenadaJ = r.Next(0, MAXIMO);
                if(tablero[coordenadaI,coordenadaJ]=='a')
                {
                    tablero[coordenadaI, coordenadaJ] = 'b';
                    barcos++;
                }
            }
            for (int i = 0; i < MAXIMO; i++)
            {
                for (int j = 0; j < MAXIMO; j++)
                {
                    Console.Write(tablero[i, j]);
                }
                Console.WriteLine();
            }

            Console.Write("Introduzca su jugada, coordenada 1: ");
            coordenadaI = Convert.ToInt32(Console.ReadLine());
            Console.Write("Coordenada 2");
            coordenadaJ = Convert.ToInt32(Console.ReadLine());

            if(tablero[coordenadaI-1,coordenadaJ-1]=='a')
            {
                Console.WriteLine("Agua");
            }
            else
            {
                Console.WriteLine("Hundido");
            }

            //TODO repetir hasta hundir todos los barcos







        }
        static void Main(string[] args)
        {

            /*  Ejercicios1y2();
              Ejercicio3();
              Ejercicio4();
            Ejercicio5();*/
            Barquitos();

        }
    }
}
