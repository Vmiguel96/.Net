﻿using System;

namespace ConsoleApp0806
{
    class Program
    {
        public static bool Salir(string palabra,string palabra2)
        {
            // devolverá si la palabra recibida como parámetro es "me rindo" --> true 
            // o no --> false
            return palabra == "me rindo" || palabra2=="me rindo";
        }
        public static bool EsCorrecto(string palabra1,string palabra2)
        {
            palabra1 = palabra1.ToLower();
            palabra2 = palabra2.ToLower();

            return palabra1[palabra1.Length - 1] == palabra2[0];

            // Pasar a minúsculas o mayúsculas ambas palabras
            // (ToLower() o ToUpper()) palabra=palabra.ToUpper()
            // Comprobar si última posición de palabra1
            // es igual a primera posición de palabra2
        }

        public static void Encadenadas()
        {
            string palabra1="";
            string palabra2 = "";

            Console.Write("Escriba la palabra inicial: ");
            palabra1 = Console.ReadLine();

            while(!Salir(palabra1,palabra2))
            {
                Console.Write("Escriba la palabra jugador 2: ");
                palabra2 = Console.ReadLine();
                if (EsCorrecto(palabra1, palabra2))
                    Console.WriteLine("Correcto!");
                else
                    Console.WriteLine("Incorrecto!");
                Console.Write("Escriba la palabra jugador 1: ");
                palabra1 = Console.ReadLine();
                if(EsCorrecto(palabra2,palabra1))
                    Console.WriteLine("Correcto!");
                else
                    Console.WriteLine("Incorrecto!");

            }
            // Pedir palabra a jugador 1
            // mientras no salir (llamada a la función Salir)
            // pedir palabra a jugador 2
            // pedir palabra a jugador 1
        }

        

        static void Main(string[] args)
        {
            bool salir = false;
            string opcion;
            // Menú repetitivo
            // 1. Palabras encadenadas
            // 2. Adivina el número
            // 3. Salir
            do
            {
                Console.WriteLine("1.- Palabras encadenadas");
                Console.WriteLine("2.- Adivina el número");
                Console.WriteLine("3.- Salir");
                opcion = Console.ReadLine();
                switch(opcion)
                {
                    case "1":
                        Encadenadas();
                        break;
                    case "2":
                        break;
                    case "3":
                        salir = true;
                        break;
                }

            } while (!salir);


            
        }
    }
}
