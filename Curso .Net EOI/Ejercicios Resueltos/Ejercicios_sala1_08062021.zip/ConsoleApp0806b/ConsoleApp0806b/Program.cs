﻿using System;

namespace ConsoleApp0806b
{
    class Program
    {
        public static void MaxMin(int[] ejemplo, ref int max, ref int min)
        {
            Array.Sort(ejemplo);
            max = ejemplo[ejemplo.Length - 1];
            min = ejemplo[0];
        }
        static void Main(string[] args)
        {
            int max = 0, min = 0;
            int[] ejemplo = { 2, 5, 1, 9, 12, 8 };
            MaxMin(ejemplo,  ref max,  ref min);
            Console.WriteLine($"El máximo es {max} y el mínimo es {min}");
        }
    }
}
