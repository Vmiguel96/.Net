﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1706
{
    public class Persona
    {
        string nombre;
        int edad;

        public int Edad
        {
            get { return edad; }
            set 
            {   if(value>0)
                    edad = value; 
            }
        }
        public Persona()
        {
            nombre = "John Doe";
            edad = 18;
        }

        public Persona(string nombre,int edad)
        {
            this.nombre = nombre;
            this.edad = edad;
        }

        public Persona(Persona p1)
        {
            this.nombre = p1.nombre;
            this.edad = p1.edad;
        }
        public string GetNombre()
        {
            return nombre;
        }

        public void SetNombre(string nombre)
        {
            this.nombre = nombre;
        }
    /*    public int GetEdad()
        {
            return edad;
        }

        public void SetEdad(int nuevaEdad)
        {
            edad = nuevaEdad;
        }
    */
        public void Saluda()
        { 
            Console.WriteLine($"Hola soy {nombre} y tengo {edad} años");
        }

    }
}
