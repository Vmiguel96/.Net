﻿using System;

namespace ConsoleApp1706
{
    class Program
    {
        static void Main(string[] args)
        {
            /* Persona persona1 = new Persona();
             Persona persona2 = new Persona("Mari Chelo", 22);
             Persona persona3 = new Persona(persona1);
             persona1.Saluda();
             persona2.Saluda();


             persona1.Saluda();
             persona2.Edad = 25;
             persona3.Edad = 33;
             persona2.Saluda();
             persona1.Saluda();
             persona3.Saluda();
             if(persona1.Edad>persona2.Edad)
             {
                 Console.WriteLine($"{persona1.GetNombre()} es mayor que {persona2.GetNombre()}");
             }
             */
            Persona[] personas = new Persona[10];
            for(int i=0;i<personas.Length;i++)
            {
                personas[i] = new Persona();
            }
            personas[0].Edad = 10;
            
            for(int i=0;i<personas.Length;i++)
            {
                personas[i].Saluda();
            }
        }
    }
}
