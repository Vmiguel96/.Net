﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1706b
{
    class Perro
    {
        private string nombre;
        private string raza;
        private int edad;

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }
        public string Raza
        {
            get { return raza; }
            set { raza = value; }
        }

        public int GetEdad()
        {
            return edad;
        }
        public void SetEdad(int edad)
        {
            this.edad = edad * 7;
        }

        public Perro()
        {
            nombre = "";
            raza = "";
        }
        public Perro(string nombre,string raza)
        {
            this.nombre = nombre;
            this.raza = raza;
        }  
        public void Ladrar()
        {
            Console.WriteLine($"{nombre}: ¡Guau!");
        }
    }
}
