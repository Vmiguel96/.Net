﻿using System;

namespace _1._3_ArraysBidimensionales
{
    class Program
    {

        public static void Ejercicio1()
        {
            string[] nombres = new string[10];
            string nombreTemp = "";
            bool encotrado = false;
            for (int i = 0; i < nombres.Length; i++)
            {
                Console.Write("Introduce un nombre:");
                nombreTemp = Console.ReadLine();
                // COMPROBAR SI EL NOMBRE EXISTE SOLO SIRVE PARA BUSCAR
                // for (int j = 0; j<nombres.Length;j++)
                for (int j = 0; j < i && !encotrado; j++) // VERSION OPTIMIZADA
                {
                    if (nombreTemp == nombres[j])
                    {
                        // YA EXISTE ESE NOMBRE
                        encotrado = true;
                        Console.WriteLine($"El nombre {nombreTemp} ya existe.");
                    }
                }

                if (encotrado == true)
                {
                    i--;
                }
                else
                {
                    nombres[i] = nombreTemp;
                }
                encotrado = false;
            }


            for (int i = 0; i < nombres.Length; i++)
            {
                Console.WriteLine($"{nombres[i]}");
            }

        }

        public static void Ejercicio2()
        {
            string nombre = "";
            int numVocales = 0;
            Console.Write("Introduce un nombre:");
            nombre = Console.ReadLine();
            nombre = nombre.ToLower();
            for (int i = 0; i < nombre.Length; i++)
            {
                if (nombre[i] == 'a' || nombre[i] == 'e' || nombre[i] == 'i' || nombre[i] == 'o' || nombre[i] == 'u')
                    numVocales++;
            }

            Console.WriteLine($"En la palabra {nombre} hay {numVocales}");
            Console.ReadKey();

        }

        public static void Ejercicio4()
        {
            string[] alumnos = { "Sara", "Eduardo", "Emilio","Carmen" };
            double[,] notas ={
                                {5,6.5,7,3.99},
                                {4,3,4.5,7},
                                {6.6,7.4,9,10},
                                {2.75,6,8,9}
                              };
            for(int i = 0; i<notas.GetLength(0);i++)
            {
                double media = 0;
                for (int j = 0; j < notas.GetLength(1); j++)
                {
                    media = media + notas[i,j];
                }
                Console.WriteLine($"La media de {alumnos[i]} es {media/notas.GetLength(1):F2}");
            }

        }


        public static void Ejercicio5()
        {
            string[] alumnos;
            double[,] notas;
            int numAlumno = 0;
            int numNotas = 0;
            double media = 0;
            Console.WriteLine("¿Cuantos alumnos vas a introducir?");
            numAlumno= Convert.ToInt32( Console.ReadLine());

            alumnos = new string[numAlumno];
            Console.WriteLine("¿Cuantas notas va a tener cada alumno?");
            numNotas = Convert.ToInt32(Console.ReadLine());
            notas = new double[numAlumno, numNotas];
            //PARTE DEL CÓDIGO PARA PEDIR NOMBRE Y NOTAS
            for (int i = 0; i < notas.GetLength(0); i++)
            {
                Console.WriteLine("Introduce el nombre del alumno:");
                alumnos[i] = Console.ReadLine();
                for (int j = 0; j < notas.GetLength(1); j++)
                {
                    Console.WriteLine($"Introduce la nota {j+1}");
                    notas[i, j] = Convert.ToDouble(Console.ReadLine());
                }
            }

            for (int i = 0; i < notas.GetLength(0); i++)
            {
                media = 0;
                for (int j = 0; j < notas.GetLength(1); j++)
                {
                    media = media + notas[i, j];
                }
                Console.WriteLine($"La media de {alumnos[i]} es {media / notas.GetLength(1):F2}");
            }

        }

        public static void Ejercicio6()
        {
            string[,] productos = {
                          {"Mesa","99,50","3"},
                          {"Silla", "14,95", "4" },
                          {"Armario", "200", "5" },
                        };
            double precio = 0;
            int cantidad = 0;

            Console.WriteLine($"{"NOMBRE",-15}{"PRECIO",10}{"CANTIDAD",10}{"TOTAL",10}");
            Console.WriteLine("---------------------------------------------");
            for (int i = 0; i < productos.GetLength(0); i++)
            {
                precio = Convert.ToDouble(productos[i, 1]);
                cantidad = Convert.ToInt32(productos[i, 2]);

                Console.WriteLine($"{productos[i,0],-15}{productos[i,1],10}{productos[i,2],10}{precio*cantidad,10}");
            }

        }

        public static void Ejercicio6BIS()
        {
            string[,] productos;
            double precio = 0;
            int cantidad = 0;
            int numProductos = 0;
            Console.Write("¿Cuántos productos va a introducir?:");
            numProductos = Convert.ToInt32(Console.ReadLine());

            productos = new string[numProductos, 3];
            
            for (int i = 0; i < productos.GetLength(0); i++)
            {
                Console.Write($"Introduce en nombre [{i+1}]:");
                productos[i, 0] = Console.ReadLine();
                Console.Write($"Introduce el precio [{i+1}]:");
                productos[i, 1] = Console.ReadLine();
                Console.Write($"Introducela cantidad [{i+1}]:");
                productos[i, 2] = Console.ReadLine();
            }

            Console.WriteLine($"{"NOMBRE",-15}{"PRECIO",10}{"CANTIDAD",10}{"TOTAL",10}");
            Console.WriteLine("---------------------------------------------");
            for (int i = 0; i < productos.GetLength(0); i++)
            {
                precio = Convert.ToDouble(productos[i, 1]);
                cantidad = Convert.ToInt32(productos[i, 2]);

                Console.WriteLine($"{productos[i, 0],-15}{productos[i, 1],10}{productos[i, 2],10}{precio * cantidad,10}");
            }

        }

        public static void Ejercicio4Escalonado()
        {
            string[] alumnos = { "Sara", "Eduardo", "Emilio", "Carmen" };
            double[,] notas ={
                                {5,6.5,7,3.99},
                                {4,3,4.5,7},
                                {6.6,7.4,9,10},
                                {2.75,6,8,9}
                              };
            double[][] notasE = {
                                 new double[] {5, 6.5, 7, 3.99, 10},
                                 new double[] {4,3,7},
                                 new double[] {6.6,7.4,9,10},
                                 new double[] {6}
                                 };

            for (int i = 0; i < notas.GetLength(0); i++)
            {
                double media = 0;
                for (int j = 0; j < notas.GetLength(1); j++)
                {
                    media = media + notas[i, j];
                }
                Console.WriteLine($"La media de {alumnos[i]} es {media / notas.GetLength(1):F2}");
            }

            for (int iE = 0; iE < notasE.Length; iE++)
            {
                double media = 0;
                for (int jE = 0; jE < notasE[iE].Length; jE++)
                {
                    media = media + notasE[iE][jE];
                }
                Console.WriteLine($"La media ESCALONADA de {alumnos[iE]} es {media / notasE[iE].Length:F2}");
            }
        }
        public static void Ejercicio6Escalonado()
        {
            string[,] productos = {
                          {"Mesa","99,50","3"},
                          {"Silla", "14,95", "4" },
                          {"Armario", "200", "5" },
                        };

            string[][] productosE = {
                                        new string[] { "Mesa", "99,50", "3" },
                                        new string[] {"Silla", "14,95", "4","20"},
                                        new string[] {"Armario", "200", "5" }
                                    };

            double precio = 0;
            int cantidad = 0;

            Console.WriteLine($"{"NOMBRE",-15}{"PRECIO",10}{"CANTIDAD",10}{"TOTAL",10}");
            Console.WriteLine("---------------------------------------------");
            for (int i = 0; i < productos.GetLength(0); i++)
            {
                precio = Convert.ToDouble(productos[i, 1]);
                cantidad = Convert.ToInt32(productos[i, 2]);


                Console.WriteLine($"{productos[i, 0],-15}{productos[i, 1],10}{productos[i, 2],10}{precio * cantidad,10}");
            }
            
            Console.WriteLine($"{"NOMBRE ESCA",-15}{"PRECIO",10}{"CANTIDAD",10}{"TOTAL",10}{"DCTO.",10}");
            Console.WriteLine("---------------------------------------------------------");
            for (int iE = 0; iE < productosE.Length; iE++)
            {
                precio = Convert.ToDouble(productosE[iE][1]);
                cantidad = Convert.ToInt32(productosE[iE][2]);
                if (productosE[iE].Length == 3)
                    Console.WriteLine($"{productosE[iE][0],-15}{productosE[iE][1],10}{productosE[iE][2],10}{precio * cantidad,10}");
                else
                    Console.WriteLine($"{productosE[iE][0],-15}{productosE[iE][1],10}{productosE[iE][2],10}{precio * cantidad,10}{productosE[iE][3],10}");
            }
        }
        //Vamos a crear una matriz cuadrada(escalonada) del tamaño que nos indique el usuario.
        //Una vez creada la matriz le asignaremos valores aleatorios entre el 0 y el 9.
        //Y por último sumaremos los elementos que conforman la diagonal de la matriz.
        //(pista[0, 0], [1, 1], [2, 2],...).
        //Deberemos mostar todos los elementos de la matriz así como el resultado de las suma
        //de los elementos que componen la diagonal.
        public static void SumaDiagonalEscalonada()
        {
            int tamano = 0;
            Console.Write("Introduce el tamaño de la matriz");
            tamano = Convert.ToInt32(Console.ReadLine());

            int [][] matriz;
            matriz = new int[tamano][];
            for (int i = 0; i < tamano; i++)
            {
                matriz[i] = new int[tamano];
            }

            Random rnd = new Random();
            int valorDiagonal = 0;
            // ASIGNO VALORES ALETORIOS A CADA UNO DE LOS ELEMENTOS DE LA MATRIZ
            // SUMO A LA VEZ QUE LE ASIGNO EL VALOR
            for (int i =0; i<matriz.Length;i++)
            { 
                for (int j = 0; j<matriz[i].Length;j++)
                {
                    
                    matriz[i][j] = rnd.Next(0, 9);
                    Console.Write($"[{matriz[i][j]}]");
                    if (i == j)
                        valorDiagonal += matriz[i][j];

                }
                Console.WriteLine();
            }
            Console.WriteLine($"La diagonal vale {valorDiagonal}");


        }


        static void Main(string[] args)
        {

            //if (args.Length == 2)
            //{
            //    if (args[0] == "antonio" && args[1] == "1234")
            //      Console.WriteLine($"Bienvenidos al progrma Xxx 2.0");
            //}
            //else 
            //{
            //    Console.WriteLine("Error: el programa necesita dos parámetros.");
            //}

            //Console.ReadKey();
            //Console.WriteLine($"He recibido {args.Length} parámetros: ");
            //foreach (string param in args)
            //{
            //    Console.WriteLine(param);
            //}
            //Ejercicio1();
            // Ejercicio2();
            //Ejercicio4();
            //Ejercicio5();
            //Ejercicio6();
            //Ejercicio6BIS();
            // Ejercicio4Escalonado();
            //Ejercicio6Escalonado();
            SumaDiagonalEscalonada();
        }
    }
}
