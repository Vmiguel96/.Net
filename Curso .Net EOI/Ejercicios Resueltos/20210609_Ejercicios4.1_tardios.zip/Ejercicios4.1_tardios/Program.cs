﻿using System;
using System.Threading;

namespace Ejercicios4._1_tardios
{
    class Program
    {
        public static void EscribeTitulo16(string cadena)
        {
            string aux = "";
            //1
            cadena = cadena.ToLower();
            // 2 Intentamos solución IsLetterOrDigit()
            for (int i = 0; i < cadena.Length; i++)
            {
                if (!Char.IsLetterOrDigit(cadena[i]))
                {
                    // QUITAMOS i y PONEMOS I
                    aux = cadena[i + 1].ToString();
                    cadena = cadena.Remove(i+1,1);
                    cadena = cadena.Insert(i+1, aux.ToUpper());
                    cadena = cadena.Remove(i,1);
                    //Console.WriteLine($"{aux}-{i}-{cadena}");
                    i--;
                }
              
            }
            Console.WriteLine($"La cadena final:{cadena}");

        }

        public static bool EsNumeroHarshad17(int numero)
        {
            string numeroLetra= numero.ToString();
            int suma = 0;
            for (int i =0; i<numeroLetra.Length;i++)
            {
                suma += Convert.ToInt32(numeroLetra[i]);
            }

            if (numero % suma == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static void CuentaParImpar18(int numero, out int pares, out int impares)
        {
            pares = 0;
            impares = 0;
            string numeroLetra = numero.ToString();
            for (int i = 0; i < numeroLetra.Length; i++)
            {
                if (Convert.ToInt32(numeroLetra[i]) % 2 == 0)
                { pares++; }
                else
                { impares++; }
            }
        }
        public static void Reloj19()
        {
            for (int i =0;i<5;)
            {
                Console.Clear();
                Console.WriteLine($"{ DateTime.Now.Hour:D2}*{DateTime.Now.Minute:D2}*{DateTime.Now.Second:D2}");
                Thread.Sleep(1000);
            }
         }

        public static void Cumpleaños2021()
        {
            string dateString = "";
            Console.Write("Escribe la fecha de tu cumpleaños [DD/MM/AAAA]:");
            dateString = Console.ReadLine();
            DateTime parsedDate = new DateTime();
           
            string[] dias = { "Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado" };

            if (DateTime.TryParse(dateString, out parsedDate))
            {
                //Método 1
                string diaHoy = dias[(int)parsedDate.DayOfWeek];
                Console.WriteLine($"Naciste ({dateString}) un {diaHoy}");

                //Método 2 sin DayOfWeek
                int posicion = 0;
                string fechaLarga = parsedDate.ToLongDateString();
                posicion=fechaLarga.IndexOf(',');
                string diaSemana = fechaLarga.Substring(0, posicion);
                Console.WriteLine($"Naciste ({dateString}) un {diaSemana}");

                //Método 2 (Super pro)
                Console.WriteLine($"Naciste (v.pro) ({dateString}) un {parsedDate.ToLongDateString().Substring(0, parsedDate.ToLongDateString().IndexOf(','))}");
            }
            else
            { 
                Console.WriteLine($"Error al convetir a fecha:{dateString}");
            }
            // ¿Cuánto falta para tu cumpleaños?
                      
            DateTime fechaModificada = new DateTime(DateTime.Now.Year, parsedDate.Month,parsedDate.Day);
            if (DateTime.Now > fechaModificada)
                fechaModificada = new DateTime(DateTime.Now.Year + 1, parsedDate.Month, parsedDate.Day);

            var horas = (DateTime.Now - fechaModificada).ToString(@"dd\d\ hh\h\ mm\m\ ");
            Console.WriteLine($"Para tu cumpleaños faltan:{horas}");

        }

        public static string Ejercicio25(string frase)
        {
            int conatadorMayusculas = 0;
            for(int i =0;i<frase.Length;i++)
            {
                if (frase[i]>='A' && frase[i]<='Z' || frase[i]=='Ñ' || frase[i] == 'Ç')
                {
                    conatadorMayusculas ++;
                }
            }

            if (conatadorMayusculas == frase.Length)
            {
                frase = frase.ToLower();
                frase = frase.Substring(0, 1).ToUpper() + frase.Substring(1);
            }

            return frase;
        }

        public static void Ejercicio26()
        {
            string nombreApellido = "";
            string cadenaReemplazo = "";
            Console.Write("Introduzca su nombre y su primer apellido:");
            nombreApellido = Console.ReadLine();
            nombreApellido = nombreApellido.Trim();
            string[] trozos = nombreApellido.Split(' ');

            if (trozos.Length >=3)
            {
                cadenaReemplazo = "Sr/Sra " + trozos[2] + ", " + trozos[0] + " " + trozos[1];
            }
            else
            { 
            // 1 solo nombre
            //Console.WriteLine(String.Join(",",trozos));
            cadenaReemplazo = "Sr/Sra " + trozos[1] + ", " + trozos[0];
            }

            Console.WriteLine(cadenaReemplazo);

        }

        static void Main(string[] args)
        {
            System.Threading.Thread.CurrentThread.CurrentCulture =
    System.Globalization.CultureInfo.CreateSpecificCulture("es-ES");

            //EscribeTitulo16("hola.que tal,,estAs");
            //if (EsNumeroHarshad17(121))
            //    Console.WriteLine("Sí es número Harshad 152");
            //else
            //    Console.WriteLine("No es número Harshad");

            //int a = 1234567;
            //int b = 0;
            //int c = 300;
            //CuentaParImpar18(a, out b, out c);
            //Console.WriteLine($"{a}-{b}-{c}");
            //// Reloj19();
            //Cumpleaños2021();
            //Console.WriteLine($"Frase modificada: {Ejercicio25("HOLaQUETAL")}");
            Ejercicio26();
        }
    }
}
