﻿using System;
using System.IO;

namespace Ejercicios5._1_ficheros
{
    class Program
    {

        public static void Explicacion()
        {
            string line;
            int contador = 0;
            StreamReader file = new StreamReader("prueba.txt");  // Declaramos variable tipo Stream reader
            while ((line = file.ReadLine()) != null)  // Recorremos con un while hasta encontrar null con ReadLine
            {
                System.Console.WriteLine(line);
                contador++;
            }
            file.Close(); // SIEMPRE HE DE CERRAR .close()
            Console.WriteLine(contador);
            Console.WriteLine("--------------------------------------------------------------");
            string texto = File.ReadAllText("Sample-Spreadsheet-100000-rows.csv");
            Console.WriteLine(texto);


            string[] lines = System.IO.File.ReadAllLines("Sample-Spreadsheet-100000-rows.csv");
            foreach (string l in lines)
            {
                System.Console.WriteLine(l);
            }

            // Utilizo split para separa lo que he leído todo de golpe
            string[] l2 = texto.Split("\n");
            Console.WriteLine(l2.Length);
            foreach (string l in l2)
            {
                System.Console.WriteLine(l);
            }
            
        }

        public static void Explicacion2()
        {
            string texto = "Contenido del archivo\ncon varias líneas2.";
            File.WriteAllText("prueba2.txt", texto);

            string[] lineas = { "Línea 1", "Línea 2", "Línea 37777" }; 
            File.WriteAllLinesAsync("prueba3.txt", lineas);

            StreamWriter writer = new StreamWriter("prueba4.txt",true); 
            foreach (string line in lineas) 
            { 
                writer.WriteLine(line); 
            }
            writer.Close();

        }

        public static void Ejercicio2()
        {

            StreamWriter writer = new StreamWriter("ejercicio2.txt");
            string cadena = "";
            
            while(cadena != "FIN")
            { 
                Console.WriteLine("Escribe las líneas hasta que escribas (FIN):");
                cadena = Console.ReadLine();
                writer.WriteLine(cadena);
            }
            writer.Close();

        }

 public static void Ejercicio1()
        {
            string linea;
            int suma = 0;
            int contLineas = 0;
            StreamReader lector = new StreamReader("numeros.txt");
            while ((linea = lector.ReadLine()) != null)
            {
                contLineas++;
            }

            lector.Close();
            int[] numeros= new int[contLineas];
            contLineas = 0;
            lector = new StreamReader("numeros.txt");
            while ((linea = lector.ReadLine()) != null)
            {
                
                suma += Convert.ToInt32(linea);
                numeros[contLineas] = Convert.ToInt32(linea);
                contLineas++;
            }
            Console.WriteLine($"{String.Join("+",numeros)}={suma}");
            lector.Close();

            suma = 0;
            // OPCION 2
            string[] lineas = File.ReadAllLines("numeros.txt");
            foreach (string li in lineas)
            { 
               suma += Convert.ToInt32(li);
            }
            Console.WriteLine($"{String.Join("+", lineas)}={suma}");

        }
        static void Main(string[] args)
        {

            //Explicacion();
            //Ejercicio1();
            //Explicacion2();
            Ejercicio2();

        }
    }
}
