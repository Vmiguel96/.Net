﻿using System;

namespace Ejercicios_2._1
{
    class Program
    {
        static void Main(string[] args)
        {
            //int numero = 0;
            //Console.Write("Introduce un número:");
            //numero = Convert.ToInt32(Console.ReadLine());

            //EJERCICIO 1
            //int numero = 0;
            //Console.Write("Introduce un número:");
            //numero = Convert.ToInt32(Console.ReadLine());
            //if (numero%2 == 0)
            //{
            //    Console.WriteLine($"El número {numero} es par. ");
            //}
            //else 
            //{
            //    Console.WriteLine($"El número {numero} es impar. ");
            //}

            // EJERCICIO 2

            //int numero = 0;
            //Console.Write("Introduce un número:");
            //numero = Convert.ToInt32(Console.ReadLine());


            //if (numero == 0)// Comprobar si es 0
            //{
            //    Console.WriteLine($"{numero} no es múltiplo de 10");
            //}
            //else
            //{
            //    if (numero % 10 == 0)//Comprobar si el resto es 0
            //    {
            //        Console.WriteLine($"{numero} SÍ es múltiplo de 10");
            //    }
            //    else
            //    {
            //        Console.WriteLine($"{numero} no es múltiplo de 10");
            //    }
            //}
            // EJERCICI0 2 (Solución 1 solo if)
            //int numero2 = 0;
            //Console.Write("Introduce un número:");
            //numero2 = Convert.ToInt32(Console.ReadLine());

            ////if (numero2 % 10 == 0 && !(numero2 == 0))
            //{
            //    Console.WriteLine($"{numero2} SÍ es múltiplo de 10");
            //}
            //else 
            //{
            //    Console.WriteLine($"{numero2} no es múltiplo de 10");
            //}

            // Otra versión de la solución con 1 if

            //if (!(numero2 % 10 == 0) || numero2 == 0)
            //{
            //    Console.WriteLine($"{numero2} NO es múltiplo de 10");
            //}
            //else
            //{
            //    Console.WriteLine($"{numero2} SÍ es múltiplo de 10");
            //}

            //  a != 0 <==> !(a == 0) expresiones equivalentes.

            //EJERCICIO 3
            //int numero = 0;
            //Console.Write("Introduce un número:");
            //numero = Convert.ToInt32(Console.ReadLine());

            //char letra;
            //Console.Write("Introduce una letra:");
            //letra = Console.ReadKey().KeyChar;


            //// Opción A (1 solo if)
            //if ((letra >= 'A' && letra <= 'Z') || letra == 'Ñ') 
            //{
            //    Console.WriteLine($"\n{letra} es una letra mayúscula");
            //}
            //else 
            //{
            //    Console.WriteLine($"\n {letra} es una letra minúscula");
            //}

            //// OPCION B (if else)
            //if ((letra >= 'A' && letra <= 'Z') )
            //{
            //    Console.WriteLine($"\n{letra} es una letra mayúscula");
            //}
            //else
            //{
            //    if (letra == 'Ñ')
            //        Console.WriteLine($"\n{letra} es una letra mayúscula");
            //    else 
            //        Console.WriteLine($"\n {letra} es una letra minúscula");
            //}

            // EJERCICIO 4

            //string cadena1, cadena2;
            //Console.Write("Introduce el texto 1:");
            //cadena1 = Console.ReadLine();

            //Console.Write("Introduce el texto 2:");
            //cadena2 = Console.ReadLine();

            ////if (cadena1 == cadena2)
            ////{
            ////    Console.WriteLine("Son iguales");
            ////}

            //if (cadena1.Equals(cadena2))
            //{
            //    Console.WriteLine("Son iguales");
            //}

            // EJERCICIO 5

            //double dividendo = 0, divisor = 0;
            //Console.Write("Introduce el dividendo:");
            //dividendo = Convert.ToDouble(Console.ReadLine());

            //Console.Write("Introduce el divisor:");
            //divisor = Convert.ToDouble(Console.ReadLine());

            //if (divisor != 0)
            //{
            //    Console.WriteLine($"La división es {dividendo / divisor:F2}");
            //}
            //else 
            //{
            //    Console.WriteLine("No puedes realizar una división por 0");
            //}

            // EJERCICIO 6
            //int numero1 = 0;
            //int numero2 = 0;
            //int numero3 = 0;

            //Console.Write("Introduce un número (1):");
            //numero1 = Convert.ToInt32(Console.ReadLine());

            //Console.Write("Introduce un número (2):");
            //numero2 = Convert.ToInt32(Console.ReadLine());

            //Console.Write("Introduce un número (3):");
            //numero3 = Convert.ToInt32(Console.ReadLine());
            // OPCION A
            //if (numero1 >= numero2 && numero1 >= numero3)
            //    Console.WriteLine($"El número mayor es {numero1}");
            //if (numero2>numero1 && numero2> numero3)
            //    Console.WriteLine($"El número mayor es {numero2}");
            //if (numero3 > numero1 && numero3 > numero2)
            //    Console.WriteLine($"El número mayor es {numero3}");

            // OPCION B
            //if (numero1 >= numero2 && numero1 >= numero3)
            //{
            //    Console.WriteLine($"El número mayor es {numero1}");
            //}
            //else if (numero2 > numero1 && numero2 > numero3)
            //        Console.WriteLine($"El número mayor es {numero2}");
            //    else
            //        Console.WriteLine($"El número mayor es {numero3}");

            // EJERCICIO 7
            int horas = 0;
            int minutos = 0;
            int segundos = 0;

            Console.Write("Introduce la hora:");
            horas = Convert.ToInt32(Console.ReadLine());

            Console.Write("Introduce los minutos:");
            minutos = Convert.ToInt32(Console.ReadLine());

            Console.Write("Introduce los segundos:");
            segundos = Convert.ToInt32(Console.ReadLine());
            // OPCION A ( Todos a la vez)
            //if (horas >= 0 && horas <= 23 && minutos >= 0 && minutos <= 59 && segundos >= 0 && segundos <= 59)
            //{
            //    Console.WriteLine($"La hora introducida es:{horas:D2}:{minutos:D2}:{segundos:D2}");
            //}
            //else
            //{
            //    Console.WriteLine("El formato de la hora no es al adecuado");
            //}

            // OPCION B ( de uno en uno)

            if (horas < 0 || horas > 23)
                Console.WriteLine("La hora es incorrecta [0-23]");
            else if (minutos < 0 || minutos > 59)
                Console.WriteLine("Los minutos son incorrectos [0-59]");
            else if (segundos < 0 || segundos > 59)
                Console.WriteLine("Los segundos son incorrectos [0-59]");
            else
                Console.WriteLine($"La hora introducida es:{horas:D2}:{minutos:D2}:{segundos:D2}");
        }
    }
}
