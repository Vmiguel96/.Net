﻿using System;

namespace ConsoleApp2705
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ejercicio 13
            /*
                        int numero;
                        bool primo = true;
                        Console.Write("Introduzca un número: ");
                        numero = Convert.ToInt32(Console.ReadLine());
                        for (int i = 1; i <= numero; i++)
                        {
                            primo = true;
                            for (int j = 2; j < i - 1; j++)
                            {
                                if (i % j == 0)
                                {
                                    primo = false;
                                }
                            }

                            if (primo)
                            {
                                Console.Write($"{i}");
                            }

                        }
            */
            //Ejercicio 14
            /*
                        int numero;
                        Console.Write("Introduzca un número: ");
                        numero = Convert.ToInt32(Console.ReadLine());
                        for (int i=numero;i>=1;i--)
                        {
                            for(int j=0;j<i;j++)
                            {
                                Console.Write("#");
                            }
                            Console.WriteLine();
                        }
            */

            //Ejercicio 15 version 1
            /*           int numero;
                       Console.Write("Introduzca un número: ");
                       numero = Convert.ToInt32(Console.ReadLine());

                       for (int fila = 1; fila <= numero; fila++)
                       {
                           for (int columna = 1; columna <= numero; columna++)
                           {

                               if (columna<fila)
                               {
                                   Console.Write(" ");
                               }
                               else
                               {
                                   Console.Write("#");
                               }
                           }
                           Console.WriteLine();
                       }
            */
            //Ejercicio 15 Version 2 (con 2 for para las columnas)
            /*
                        int numero;
                        Console.Write("Introduzca un número: ");
                        numero = Convert.ToInt32(Console.ReadLine());

                        for(int fila=0;fila<numero;fila++)
                        {

                                for(int espacios=0;espacios<fila;espacios++)
                                { 
                                    Console.Write(" ");
                                }
                                for(int caracteres=0;caracteres<numero-fila;caracteres++)
                                {
                                    Console.Write("#");
                                }

                            Console.WriteLine();
                        }
            */

            //Ejercicio 16
            /*
             int numero;
             Console.Write("Introduzca un número: ");
             numero = Convert.ToInt32(Console.ReadLine());
             int resultado = 1;
             for(int i=numero;i>0;i--)
             {
                 resultado *= i;
             }
             Console.WriteLine($"El factorial de {numero} es {resultado}");
 */
            //Ejercicio 17
            /*
                        int cantidad=1, precio=1, total=0, totalFinal=0;

                        while(cantidad!=0 && precio!=0)
                        {
                            Console.Write("Introduzca cantidad: ");
                            cantidad = Convert.ToInt32(Console.ReadLine());

                            Console.Write("Introduzca precio: ");
                            precio = Convert.ToInt32(Console.ReadLine());

                            if (cantidad != 0 && precio != 0)
                            {
                                total = cantidad * precio;
                                totalFinal += total;
                                Console.WriteLine($"Total: {total}");
                            }
                        }
                        Console.WriteLine($"Total Final: {totalFinal}");
            */

            //Ejercicio 18
            /*
                        int numero1,numero2,contador=0;
                        bool primo = true;
                        Console.Write("Introduzca un número: ");
                        numero1 = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Introduzca un número: ");
                        numero2 = Convert.ToInt32(Console.ReadLine());
                        for (int i = numero1; i <= numero2; i++)
                        {
                            primo = true;
                            for (int j = 2; j < i - 1; j++)
                            {
                                if (i % j == 0)
                                {
                                    primo = false;
                                }
                            }

                            if (primo)
                            {
                                contador++;
                            }

                        }

                        Console.WriteLine($"Hay {contador} números primos");
               */

            //Ejercicio 19
     /*
            int numero1,numero2,numero;
            Console.Write("Introduzca un número: ");
            numero1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Introduzca un número: ");
            numero2 = Convert.ToInt32(Console.ReadLine());

            if(numero1>numero2)
            {
                numero = numero2;
            }
            else
            {
                numero = numero1;
            }
            for (int i=1;i<=numero;i++)
            {
                if(numero1%i==0 && numero2%i==0)
                {
                    Console.Write(i+" ");
                }
            }
     */
            //Ejercicio 21
            /*
                        int numero=1,contador=0;

                        while (numero != 0)
                        {
                            Console.Write("Introduzca un número: ");
                            numero = Convert.ToInt32(Console.ReadLine());
                            if (numero != 0 && numero%5==0)
                            {
                                contador++;
                            }

                        }
                        Console.WriteLine($"Hay {contador} múltiplos de 5");

            */
        }
    }
}
