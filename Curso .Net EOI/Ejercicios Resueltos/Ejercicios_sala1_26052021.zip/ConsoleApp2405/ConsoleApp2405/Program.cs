﻿using System;

namespace ConsoleApp2405
{
    class Program
    {
        static void Main(string[] args)
        {
            /*string password = "";
            //Ejercicio 1 while
            while(password!="1111")
            {
                Console.Write("Introduzca contraseña:");
                password = Console.ReadLine();
            }
            Console.WriteLine("Contraseña correcta!");*/

            //Ejercicio 1 do ... while
            /*string password;
            do
            {
                Console.Write("Introduzca contraseña:");
                password = Console.ReadLine();
            } while (password != "1111");
            Console.WriteLine("Contraseña correcta!");*/

            //Ejercicio 2 while
            /*int numero = 1;
            while(numero!=0)
            {
                Console.Write("Introduzca un número:");
                numero = Convert.ToInt32(Console.ReadLine());
                if (numero != 0)
                {
                    if (numero % 2 == 0)
                    {
                        Console.WriteLine($"{numero} es par");
                    }
                    else
                    {
                        Console.WriteLine($"{numero} es impar");
                    }
                }
            }*/

            //Ejercicio 2 do while
            /* int numero;
             do
             {
                 Console.Write("Introduzca un número:");
                 numero = Convert.ToInt32(Console.ReadLine());
                 if (numero != 0)
                 {
                     if (numero % 2 == 0)
                     {
                         Console.WriteLine($"{numero} es par");
                     }
                     else
                     {
                         Console.WriteLine($"{numero} es impar");
                     }
                 }
             } while (numero != 0);*/

            // Ejercicio 3 while
            /*int numerador, denominador = 0;

            Console.Write("Introduzca numerador:");
            numerador = Convert.ToInt32(Console.ReadLine());

            while (denominador == 0)
            {
                Console.Write("Introduzca denominador:");
                denominador = Convert.ToInt32(Console.ReadLine());
            }

            Console.WriteLine($"El resultado de {numerador}/{denominador} es {numerador / denominador}");
            */
            /* //Ejercicio 3 do ... while
             int numerador, denominador;

             Console.Write("Introduzca numerador:");
             numerador = Convert.ToInt32(Console.ReadLine());

             do
             {
                 Console.Write("Introduzca denominador:");
                 denominador = Convert.ToInt32(Console.ReadLine());
             } while (denominador == 0);
             Console.WriteLine($"El resultado de {numerador}/{denominador} es {numerador / denominador}");
            */

            //Ejercicio 4
            /*int numero1, numero2;

            Console.Write("Introduzca un número:");
            numero1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Introduzca un número:");
            numero2 = Convert.ToInt32(Console.ReadLine());
            int cuantos = 0;

            if(numero1>0 && numero2>0)
            {
                Console.WriteLine("Los 2 número son positivos");
            }
            else if(numero1<0 && numero2 < 0)
            {
                Console.WriteLine("Ninguno de los 2 números es positivo");
            }
            else
            {
                Console.WriteLine("Uno de los números es positivo");
            }

            cuantos = numero1 > 0 && numero2 > 0 ? 2 : numero1 < 0 && numero2 < 0 ? 0 : 1;

            Console.WriteLine($"Hay {cuantos} numeros positivos");
            */
            /*int veces=2, contador=0,numero;

            while(veces>0)
            {
                Console.Write("Introduzca un número:");
                numero = Convert.ToInt32(Console.ReadLine());
                if(numero>0)
                {
                    contador++;
                }
                veces--;
            }
            Console.WriteLine($"Hay {contador} números positivos");
            */
            //Ejercicio 6
            /* int numero = 1,contadorPositivos=0,contadorNegativos=0;
             while(numero!=0)
             {
                 Console.Write("Introduzca un número:");
                 numero = Convert.ToInt32(Console.ReadLine());
                 if(numero>0)
                 {
                     contadorPositivos++;
                 }
                 else if(numero<0)
                 {
                     contadorNegativos++;
                 }
             }
             Console.WriteLine($"Hay {contadorPositivos} números positivos y {contadorNegativos} negativos");
            */
            //Ejercicio 7
            string usuario, password;
            do
            {
                Console.Write("Introduzca usuario:");
                usuario = Console.ReadLine();
                Console.Write("Introduzca contraseña:");
                password = Console.ReadLine();
            } while (usuario != "1212" || password != "1234");



        }
    }      
}
