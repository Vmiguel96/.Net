﻿using System;

namespace Parte2Ejercicios3
{
    class Program
    {
        static void Main(string[] args)
        {
            //int n1 = 9;
            //int n2 = 7;
            //int diferenencia = n1 > n2 ? n1 - n2 : n2 - n1;
            //Console.WriteLine(diferenencia);

            //int n12 = 9;
            //int n22 = 7;
            //int diferencia2;
            //if (n1 > n2)
            //    diferencia2 = n12 - n22;
            //else
            //    diferencia2 = n22 - n12;

            //Console.WriteLine(diferenencia);


            // EJERCICIO 8
            //int numero = 0;
            //Console.Write("Escribe un número:");
            //numero = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine($"El {numero} es {(numero % 2 == 0 ? "par" : "impar")}");

            // REPETIMOS el 1.2.2 con operador ternario
            //int numero2 = 0;
            //Console.Write("Introduce un número:");
            //numero2 = Convert.ToInt32(Console.ReadLine());

            //Console.WriteLine($"El {numero2} {(numero2 % 10 == 0 && !(numero2 == 0)?"SÍ" :"NO" )} es múltiplo de 10");


            //if (numero2 % 10 == 0 && !(numero2 == 0))
            //{
            //    Console.WriteLine($"{numero2} SÍ es múltiplo de 10");
            //}
            //else
            //{
            //    Console.WriteLine($"{numero2} no es múltiplo de 10");
            //}

            // Con doble operador ternario

            //if (numero == 0)// Comprobar si es 0
            //{
            //    Console.WriteLine($"{numero} no es múltiplo de 10");
            //}
            //else
            //{
            //    if (numero % 10 == 0)//Comprobar si el resto es 0
            //    {
            //        Console.WriteLine($"{numero} SÍ es múltiplo de 10");
            //    }
            //    else
            //    {
            //        Console.WriteLine($"{numero} no es múltiplo de 10");
            //    }
            //}

            //Console.WriteLine($"El {numero2} {(numero2== 0? "NO":numero2 % 10 == 0?"SÍ":"No")} es múltiplo de 10");
            // EJERCICIOS EXTRA 1
            //int numero3 = 0;
            //Console.Write("Introduce un número:");
            //numero3 = Convert.ToInt32(Console.ReadLine());

            //int variablesigno = (numero3 > 0 ? 1 : (numero3 < 0 ? -1 : 0));

            //Console.WriteLine($"La variable tiene el valor {variablesigno}");
            // EJERCICIOS EXTRA 2

            //int numero4 = 0;
            //Console.Write("Introduce un número:");
            //numero4 = Convert.ToInt32(Console.ReadLine());

            //int multiplo = numero4 % 2 == 0 && numero4 % 3 == 0?1:0;
            //Console.WriteLine($"El número {numero4} {(multiplo==1?"SI":"NO")} es múltiplo de 2 y de 3.");

            // ÁMBITO DE LAS VARIABLES
            //if (numero4 == 3)
            //{
            //    int fueraRango = 0;
            //    numero4 = 4;

            //}
            //else
            //{
            //    numero4 = fueraRango;
            //}

            // EJERCICIO EXTRA 5
            //double sueldo = 0, antiguedad = 0;
            //Console.Write("Introduce el salario del empleado:");
            //sueldo = Convert.ToDouble(Console.ReadLine());
            //Console.Write("Introduce la antigüedad del empleado:");
            //antiguedad = Convert.ToDouble(Console.ReadLine());

            //// OPCION A
            //if (sueldo < 500 && antiguedad >= 10)
            //{
            //    Console.WriteLine($"El nuevo sueldo del empleado será {sueldo * 0.2 + sueldo}");
            //}
            //else if (sueldo < 500 && antiguedad < 10)
            //{
            //    Console.WriteLine($"El nuevo sueldo del empleado será {sueldo * 0.05 + sueldo}");
            //}
            //else
            //{
            //    Console.WriteLine($"El nuevo sueldo del empleado será {sueldo}");
            //}

            // OPCION B
            //if (sueldo < 500 && antiguedad >= 10)
            //{
            //    Console.WriteLine($"El nuevo sueldo del empleado será {sueldo * 0.2 + sueldo}");
            //}
            //if (sueldo < 500 && antiguedad < 10)
            //{
            //    Console.WriteLine($"El nuevo sueldo del empleado será {sueldo * 0.05 + sueldo}");
            //}
            //if (sueldo >= 500)
            //{ 
            //    Console.WriteLine($"El nuevo sueldo del empleado será {sueldo}");
            //}
            //EJERCICIO EXTRA 6

            // EJERCICIO EXTRA 7
            int cantidad = 0;
            int cantidaRestante = 0;
            int c500, c200, c100, c50, c20, c10, c5, c1;
            Console.Write("Introduce la cantidad deseada:");
            cantidad = Convert.ToInt32(Console.ReadLine());
            
            
            cantidaRestante = cantidad;
            
            if (cantidaRestante >= 500)
            {
                c500 = cantidad / 500;
                cantidaRestante = cantidaRestante % 500;
            }
            else
            {
                c500 = 0;
            }

            if (cantidaRestante >= 200)
            {
                c200 = cantidaRestante / 200;
                cantidaRestante = cantidaRestante % 200;
            }
            else
            { 
                c200 = 0;
            }

            if (cantidaRestante >= 100)
            {
                c100 = cantidaRestante / 100;
                cantidaRestante = cantidaRestante % 100;
            }
            else
            { 
                c100 = 0;
            }

            if (cantidaRestante >= 50)
            {
                c50 = cantidaRestante / 500;
                cantidaRestante = cantidaRestante % 500;
            }
            else
            {
                c50 = 0;
            }

            if (cantidaRestante >= 20)
            {
                c20 = cantidaRestante / 20;
                cantidaRestante = cantidaRestante % 20;
            }
            else
            {
                c20 = 0;
            }


            if (cantidaRestante >= 10)
            {
                c10 = cantidaRestante / 10;
                cantidaRestante = cantidaRestante % 10;
            }
            else
            {
                c10 = 0;
            }

            if (cantidaRestante >= 5)
            {
                c5 = cantidaRestante / 5;
                cantidaRestante = cantidaRestante % 5;
            }
            else
            {
                c5 = 0;
            }

            c1 = cantidaRestante;


            Console.WriteLine($"La cantidad de Billetes de 500 es:{c500}");
            Console.WriteLine($"La cantidad de Billetes de 200 es:{c200}");
            Console.WriteLine($"La cantidad de Billetes de 100 es:{c100}");
            Console.WriteLine($"La cantidad de Billetes de 50 es:{c50}");
            Console.WriteLine($"La cantidad de Billetes de  20 es:{c20}");
            Console.WriteLine($"La cantidad de Billetes de  10 es:{c10}");
            Console.WriteLine($"La cantidad de Billetes de   5 es:{c5}");
            Console.WriteLine($"La cantidad de monedas de    1 es:{c1}");

        }
    }
}
