﻿using System;

namespace Ejercicios2._2_for
{
    class Program
    {
        static void Main(string[] args)
        {
            // EJERCICIO 1
            //for (int i = 20; i >= 1; i--)
            //{
            //    Console.WriteLine($"{i}");
            //}

            // EJERCICIO 2
            //int numero = 0;
            //int suma = 0;

            //do
            //{
            //    Console.Write($"Introduce un número:");
            //    numero = Convert.ToInt32(Console.ReadLine());
            //    suma = suma + numero;
            //    Console.WriteLine($"El total acumulado es {suma}");
            //} 
            //while(numero != 0);

            //for (int i = 0; i <= 0; i--)
            //{
            //    Console.Write($"Introduce un número:");
            //    numero = Convert.ToInt32(Console.ReadLine());
            //    suma = suma + numero;
            //    Console.WriteLine($"El total acumulado es {suma}");
            //    if (numero == 0)
            //        break;
            //}

            // EJERCICIO 3
            //int numero = 0;
            //int cifras = 0;
            //Console.Write($"Introduce un número:");
            //numero = Convert.ToInt32(Console.ReadLine());
            //for (int i = 0; i <= 0; i--)
            //{
            //    numero = numero / 10;
            //    cifras++;
            //    //250/10 = 25 --> 25/10 = 2 --> 2/10 = 0
            //    if (numero == 0) // CONDICION CHUSQUERA PARA SALIR
            //       i = 23;
            //}
            //Console.WriteLine($"Hay {cifras} cifras.");

            // EJERCICIO 4
            //int numero = 0;
            //Console.Write($"Introduce un número:");
            //numero = Convert.ToInt32(Console.ReadLine());
            //for (int i = 1;i<=numero; i++) // int i=0; i<numero; i++
            //{
            //    Console.Write("*");
            //}

            //EJERCICIO 5
            //for (int i = 1; i <= 30; i++) // int i=0; i<numero; i++
            //{
            //    if (i % 3 == 0)
            //        Console.WriteLine($"{i}");
            //}
            ////EJERCICIO 6
            //for (int i = 1; i <= 100; i++) // int i=0; i<numero; i++
            //{
            //    if (i % 5 == 0)
            //        Console.WriteLine($"{i}");
            //}

            //for (int i = 0; i <= 100; i=i+5) 
            //{
            //        Console.WriteLine($"{i}");
            //}

            // EJERCICIO 7
            //int numero = 0;
            //Console.Write($"Introduce un número:");
            //numero = Convert.ToInt32(Console.ReadLine());
            //for(int i = 1;i<=numero;i++)
            //{

            //    if(i == numero)
            //        Console.Write($"{i}");
            //    else
            //        Console.Write($"{i}, ");
            //}
            // EJERCICIO 8 RESUELTO EN EL 2
            // EJERCICIO 9
            //int numero = 0;
            //Console.Write($"Introduce un número:");
            //numero = Convert.ToInt32(Console.ReadLine());

            //for(int i = numero; i>=1; i--)
            //{
            //    if (numero % i == 0)
            //        Console.Write($"{i} ");
            //}

            // EJERCICIO 10
            //for (int i = 1;i<=5;i++)
            //{   
            //    for (int j = 1;j<=9;j++)
            //    {
            //        Console.Write($"{j}");
            //    }
            //    //Console.Write("\n");
            //}


            // EJERCICIO 11
            //for (int i = 9; i >= 1; i--)
            //{
            //    for (int j = 1; j <= i; j++)
            //    {
            //        Console.Write($"{j}");
            //    }
            //    Console.Write("\n");
            //}

            // EJERCICIO 12
            int numero = 0;
            Console.Write($"Introduce un número:");
            numero = Convert.ToInt32(Console.ReadLine());
            //for (int filas = 1; filas <= numero; filas++)
            //{
            //    for (int columnas = 1; columnas <= numero; columnas++)
            //    {
            //        Console.Write("*");
            //    }
            //    Console.Write("\n");
            //}

            // EJERCICIO 13
            //for(int filas = 1;filas<= numero; filas ++)
            //{
            //    for (int col=1; col <= filas; col++)
            //    {
            //        Console.Write("*");
            //    }
            //    Console.Write("\n");

            //}

            // EJERCICIO 14

            for (int filas = 1; filas <= numero; filas++)
            {
                for (int columnas = 1; columnas <= numero; columnas++)
                {
                    if (columnas <= numero - filas)
                        Console.Write(" ");
                    else
                        Console.Write("*");
                }
                Console.Write("\n");
            }

            // EJERCICIO 15
            //15.Pide al usuario un ancho y un alto y dibuja un rectángulo vacío.
            //Dime un ancho: 5
            //Dime un alto: 4
            //*****
            //*   *
            //*   *
            //*****
            //Console.WriteLine("Introduce una anchura");
            //int anchura = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("Introduce una altura");
            //int altura = Convert.ToInt32(Console.ReadLine());
            //for (int fila = 1; fila <= altura; fila++)
            //{
            //    for (int col = 1; col <= anchura; col++)
            //    {
            //        if (fila == 1 || fila == altura || col == 1 || col == anchura)
            //        {
            //            Console.Write("*");
            //        }
            //        else
            //        {
            //            Console.Write(" ");
            //        }
            //    }
            //    Console.WriteLine();
            //}


            //16.Pide al usuario un número que será la altura de una pirámide.Dibuja una
            //pirámide con asteriscos con dicha altura
            //Pista: El ancho(base) de la pirámide será: (altura * 2 – 1), y la posición del
            //primer asterisco será el mismo que la altura si empiezas el bucle en 1(o una menos
            //si lo quieres empezar en 0).Crea 2 variables auxiliares con la posición del primer
            //asterisco, una la irás decrementando y otra incrementando. Si la posición actual
            //está entre esas 2 variables dibujas un asterisco, y si no, un espacio.
            //Dime la altura de la pirámide: 4
            //   *
            //  ***
            // *****
            //*******           // 2 FOR Y EN EL SEGUNDO FOR EL IF-ELSE

            //Console.WriteLine("Dime la altura de la pirámide:");
            //int alto = Convert.ToInt32(Console.ReadLine());
            //int ancho = alto * 2 - 1;
            //for (int fila = 0; fila < alto; fila++)
            //{
            //    for (int col = 1; col <= ancho; col++)
            //    {
            //        if (col < alto - fila || col > alto + fila)
            //        {
            //            System.Console.Write(" ");
            //        }
            //        else
            //        {
            //            System.Console.Write("*");
            //        }
            //    }
            //    System.Console.WriteLine();
            //}


           //17.Intenta hacer lo mismo pero con una pirámide hueca:

            //Dime la altura de la pirámide: 4
            //   *
            //  * *
            // *   *
            //*******

            //System.Console.Write("Dime el alto: ");
            //int alto = Convert.ToInt32(Console.ReadLine());
            //int ancho = alto * 2 - 1;
            //for (int fila = 0; fila < alto; fila++)
            //{
            //    for (int col = 1; col <= ancho; col++)
            //    {
            //        if (col == alto - fila || col == alto + fila || fila == alto - 1)
            //        {
            //            System.Console.Write("*");
            //        }
            //        else
            //        {
            //            System.Console.Write(" ");
            //        }
            //    }
            //    System.Console.WriteLine();
            //}

            //18.Dibuja ahora una pirámide invertida
            //Dime la altura de la pirámide: 4
            //*******
            // *****
            //  ***
            //   *

            //System.Console.Write("Dime el alto: ");
            //int alto = Convert.ToInt32(Console.ReadLine());
            //int ancho = alto * 2 - 1;
            //for (int fila = alto - 1; fila >= 0; fila--)
            //{
            //    for (int col = 1; col <= ancho; col++)
            //    {
            //        if (col < alto - fila || col > alto + fila)
            //        {
            //            System.Console.Write(" ");
            //        }
            //        else
            //        {
            //            System.Console.Write("*");
            //        }
            //    }
            //    System.Console.WriteLine();
            //}


            //19.Ahora dibuja un rombo(puedes dibujar una pirámide y posteriormente una
            //pirámide invertida).Pide al usuario el ancho del rombo, que deberá ser un
            //número impar(sigue pidiéndole un número hasta que introduzca uno impar).
            //Si quieres hacerlo con 2 pirámides, la altura de la primera sería(ancho +1) / 2
            //Dime la base del rombo: 5
            //  *
            // ***
            //*****
            // ***
            //  *
            System.Console.Write("Dime el ancho: ");
            int ancho = Convert.ToInt32(Console.ReadLine());

            int alto = ancho / 2 + 1;
            for (int fila = 0; fila < alto; fila++)
            {
                for (int col = 1; col <= ancho; col++)
                {
                    if (col < alto - fila || col > alto + fila)
                    {
                        System.Console.Write(" ");
                    }
                    else
                    {
                        System.Console.Write("*");
                    }
                }
                System.Console.WriteLine();
            }

            for (int fila = alto - 2; fila >= 0; fila--)
            {
                for (int col = 1; col <= ancho; col++)
                {
                    if (col < alto - fila || col > alto + fila)
                    {
                        System.Console.Write(" ");
                    }
                    else
                    {
                        System.Console.Write("*");
                    }
                }
                System.Console.WriteLine();
            }




        }
    }
}
