﻿using System;
using System.IO;

namespace ConsoleApp1506
{
    
    class Program
    {
        public static void Ejercicio4()
        {
            try
            {
                StreamWriter writer = new StreamWriter("TextEjercicio02.txt",true);

                for (int i = 100; i < 200; i++)
                {
                    writer.WriteLine($"Linea {i + 1}");
                }
                writer.Close();
            }
            catch (ArgumentNullException)
            {
                Console.WriteLine("Error en el fichero puntero nulo");
            }
            catch (ArgumentException)
            {
                Console.WriteLine("Error en el fichero");
            }
            catch (IOException)
            {
                Console.WriteLine("Excepción");
            }

        }
        public static void Ejercicio5()
        {
            string line;
            int contadorLinea = 0;
            try
            {
                StreamReader miFichero = new StreamReader("prueba.txt");
                while ((line = miFichero.ReadLine()) != null) 
                {
                    contadorLinea++;
                    if (line != "")
                    {
                        if (line[0] == 'A' || line[0] == 'a')
                            Console.WriteLine($"{contadorLinea}: {line}");
                    }
                }

                miFichero.Close();
            }
           
            catch (FileNotFoundException)
            {
                Console.WriteLine("Fichero no encontrado");
            }
            catch (IOException)
            {
                Console.WriteLine("Excepción");
            }

        }
        public static void Ejercicio5b()
        {
           
            try
            {
                string[] lineas = File.ReadAllLines("prueba.txt");
                for(int i=0;i<lineas.Length;i++)
                {
                    if (lineas[i][0] == 'A' || lineas[i][0] == 'a')
                    {
                        Console.WriteLine($"{i+1}: {lineas[i]}");
                    }

                }
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("Fichero no encontrado");
            }
            catch (IOException)
            {
                Console.WriteLine("Error con el fichero");
            }

        }
        public static void Ejercicio6()
        {
            string linea;
            int contador=0;
            Console.Write("Introduzca el nombre del fichero:");
            string fichero = Console.ReadLine();
            if (File.Exists(fichero))
            {
                StreamReader miFichero = new StreamReader(fichero);
                while((linea=miFichero.ReadLine())!=null)
                {
                    contador++;
                }
                miFichero.Close();
                Console.WriteLine($"El fichero {fichero} tiene {contador} líneas");
                string[] lineas = File.ReadAllLines(fichero);
                Console.WriteLine($"El fichero {fichero} tiene {lineas.Length} líneas");

            }
            else
            {
                Console.WriteLine("No existe el fichero");
            }
        }
        public static void Ejercicio7()
        {
            string linea;
            StreamWriter frases = new StreamWriter("frases.txt", true);
            Console.Write("Introduzca una frase:");
            while ((linea = Console.ReadLine()) != "")
            {
                frases.WriteLine(linea);
                Console.Write("Introduzca una frase:");
            }
            frases.Close();
        }
        public static void Ejercicio8()
        {
            string linea;
            int palabras = 0;
            Console.Write("Introduzca nombre de fichero: ");
            string nombre = Console.ReadLine();
            try
            {
                StreamReader fichero = new StreamReader(nombre);
                while ((linea = fichero.ReadLine()) != "")
                {
                    palabras += linea.Split().Length;
                }
                fichero.Close();
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("Fichero no existe");
            }
            catch
            {
                Console.WriteLine("Error con el fichero");
            }
            //Versión Samuel
            //string contenido = File.ReadAllText(path);
            //palabras = contenido.Spilt().Length;

        }
        static void Main(string[] args)
        {
            //Ejercicio4();
            //Ejercicio5();
            //Ejercicio5b();
            //Ejercicio6();
            Ejercicio7();
        }
    }
}
