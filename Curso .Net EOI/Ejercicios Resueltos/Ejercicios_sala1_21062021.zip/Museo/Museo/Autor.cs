﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Museo
{
    public class Autor
    {
        string nombre;

        public string Nombre { get => nombre; set => nombre = value; }

        public Autor(string nombre)
        {
            this.nombre = nombre;
        }
        public Autor():this("anónimo")
        {
            
        }
        public override string ToString()
        {
            return "Autor: "+nombre;
        }

    }
}
