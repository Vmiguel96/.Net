﻿using System;

namespace Museo
{
    class Program
    {
        static void Main(string[] args)
        {
            string autor,nombre,propietario,escultura,material;
            int year;

            
            Obra[] misObras = new Obra[3];
            for(int i=0;i<misObras.Length;i++)
            {
                Console.Write("Nombre Autor:");
                autor = Console.ReadLine();
                Autor miAutor = new Autor(autor);
                Console.Write("Nombre Obra:");
                nombre = Console.ReadLine();
                Console.Write("Nombre Propietario:");
                propietario = Console.ReadLine();
                Console.Write("Año Creación:");
                year = Convert.ToInt32(Console.ReadLine());
                Console.Write("(E)scultura o (P)intura");
                escultura = Console.ReadLine();
                if (escultura == "E")
                {
                    Console.Write("Material:");
                    material = Console.ReadLine();
                    misObras[i] = new Escultura(miAutor, propietario, nombre, year, material);
                }
                else
                    misObras[i] = new Pintura(miAutor, propietario, nombre, year);
            }
            for(int i=0;i<misObras.Length;i++)
            {
                Console.WriteLine(misObras[i]);
            }
            
          

            //Pedir datos para 10 obras y rellenar el array
            //Preguntar si es Pintura o Escultura y pedir datos según sea
            //Recorrer el array y mostrar los datos
            //El usuario nos proporciona el nombre del autor
            //--> tenemos que crear Objeto Autor para poner en el constructor de Pintura o ES
        }
    }
}
