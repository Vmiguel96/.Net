﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Museo
{
    public class Escultura:Obra
    {
        string material;

        public string Material { get => material; set => material = value; }

        public Escultura(Autor autor, string propietario, 
            string nombre, int year,string material):base(autor,propietario,nombre,year)
        {
            this.material = material;
        }

        public Escultura():this(new Autor(),"","",0,"")
        {

        }

        public override string ToString()
        {
            return base.ToString() + " Material: " + material;
        }
    }
}
