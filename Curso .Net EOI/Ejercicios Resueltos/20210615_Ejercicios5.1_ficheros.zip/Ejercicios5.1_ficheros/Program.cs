﻿using System;
using System.IO;

namespace Ejercicios5._1_ficheros
{
    class Program
    {

        public static void Explicacion()
        {
            string line;
            int contador = 0;
            StreamReader file = new StreamReader("prueba.txt");  // Declaramos variable tipo Stream reader
            while ((line = file.ReadLine()) != null)  // Recorremos con un while hasta encontrar null con ReadLine
            {
                System.Console.WriteLine(line);
                contador++;
            }
            file.Close(); // SIEMPRE HE DE CERRAR .close()
            Console.WriteLine(contador);
            Console.WriteLine("--------------------------------------------------------------");
            string texto = File.ReadAllText("Sample-Spreadsheet-100000-rows.csv");
            Console.WriteLine(texto);


            string[] lines = System.IO.File.ReadAllLines("Sample-Spreadsheet-100000-rows.csv");
            foreach (string l in lines)
            {
                System.Console.WriteLine(l);
            }

            // Utilizo split para separa lo que he leído todo de golpe
            string[] l2 = texto.Split("\n");
            Console.WriteLine(l2.Length);
            foreach (string l in l2)
            {
                System.Console.WriteLine(l);
            }

        }

        public static void Explicacion2()
        {
            string texto = "Contenido del archivo\ncon varias líneas2.";
            File.WriteAllText("prueba2.txt", texto);

            string[] lineas = { "Línea 1", "Línea 2", "Línea 37777" };
            File.WriteAllLinesAsync("prueba3.txt", lineas);

            StreamWriter writer = new StreamWriter("prueba4.txt", true);
            foreach (string line in lineas)
            {
                writer.WriteLine(line);
            }
            writer.Close();

        }



        public static void Ejercicio1()
        {
            string linea;
            int suma = 0;
            int contLineas = 0;
            StreamReader lector = new StreamReader("numeros.txt");
            while ((linea = lector.ReadLine()) != null)
            {
                contLineas++;
            }

            lector.Close();
            int[] numeros = new int[contLineas];
            contLineas = 0;
            lector = new StreamReader("numeros.txt");
            while ((linea = lector.ReadLine()) != null)
            {

                suma += Convert.ToInt32(linea);
                numeros[contLineas] = Convert.ToInt32(linea);
                contLineas++;
            }
            Console.WriteLine($"{String.Join("+", numeros)}={suma}");
            lector.Close();

            suma = 0;
            // OPCION 2
            string[] lineas = File.ReadAllLines("numeros.txt");
            foreach (string li in lineas)
            {
                suma += Convert.ToInt32(li);
            }
            Console.WriteLine($"{String.Join("+", lineas)}={suma}");

        }

        public static void Ejercicio2()
        {

            StreamWriter writer = new StreamWriter("ejercicio2.txt");
            string cadena = "";

            while (cadena != "FIN")
            {
                Console.WriteLine("Escribe las líneas hasta que escribas (FIN):");
                cadena = Console.ReadLine();
                writer.WriteLine(cadena);
            }
            writer.Close();

        }
        public static void Ejercicio3()
        {
            double media = 0;
            string perNotaAlta = "";
            string perNotaBaja = "";
            double notaBaja = 10;
            double notaAlta = 0;

            string ruta = Path.Join("archivos", "alumnos.txt");
            //StreamReader archivo = new StreamReader(ruta);
            try
            {
                string[] lineas = File.ReadAllLines(ruta);
                foreach (string linea in lineas)
                {
                    string[] trozos = linea.Split(";");
                    string nombre = trozos[0];
                    double nota = Convert.ToDouble(trozos[1]);

                    media += nota;
                    // MEJOR NOTA
                    if (nota > notaAlta)
                    {
                        notaAlta = nota;
                        perNotaAlta = nombre;
                    }
                    //PEOR NOTA
                    if (nota < notaBaja)
                    {
                        notaBaja = nota;
                        perNotaBaja = nombre;
                    }

                }
                media = media / lineas.Length;
                Console.WriteLine($"La nota media es:{media}");
                Console.WriteLine($"La nota mas baja es {notaBaja} de {perNotaBaja}");
                Console.WriteLine($"La nota mas baja es {notaAlta} de {perNotaAlta}");
            }
            catch (PathTooLongException exp)
            {
                Console.WriteLine("La ruta del archivo es demasiado larga:" + exp.Message);
            }
            catch (FileNotFoundException exp)
            {
                Console.WriteLine("No se encuentra el archivo:" + exp.Message);

            }
            catch (Exception exp)
            {
                Console.WriteLine("Error desconocido:" + exp.Message);
            }

        }
        public static void Menu()
        {
            int opcion = -1;
            bool salida = false;
            do
            {
                Console.WriteLine("\nMENÚ");
                Console.WriteLine("\t1) Mostrar productos");
                Console.WriteLine("\t2) Añadir productos");
                Console.WriteLine("\t0) Salir");
                Console.Write("\tElija una opción:");
                try
                {
                    opcion = Convert.ToInt32(Console.ReadLine());
                }
                catch (Exception e)
                {
                    opcion = -1;
                }

                switch (opcion)
                {
                    case 0:
                        salida = true;
                        break;
                    case 1:
                        MostrarProductos();
                        break;
                    case 2:
                        EscribirProductos();
                        break;
                    default:
                        Console.WriteLine("Opción no reconocida");
                        break;
                }
            }
            while (!salida);
        }

        public static void MostrarProductos()
        {

            string ruta = Path.Join("archivos", "productos.txt");

            Console.WriteLine("\n         MOSTRAR PRODUCTOS");
            Console.WriteLine("---------------------------------------------");

            try
            {
                string[] lineas = File.ReadAllLines(ruta);
                foreach (string linea in lineas)
                {
                    string[] trozos = linea.Split(";");
                    double precio = Convert.ToDouble(trozos[1]);
                    Console.WriteLine($"{trozos[0],-20}{precio,10:F2}");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Se ha producido un error:" + e.Message);
            }



        }


        public static void EscribirProductos()
        {
            string ruta = Path.Join("archivos", "productos.txt");
            string nombre = "";
            double precio = 0;
            Console.WriteLine("\n       ESCRIBIR PRODUCTOS");
            Console.WriteLine("---------------------------------------------");
            Console.Write("Introduzca el nombre del producto:");
            nombre = Console.ReadLine();
            Console.Write("Introduzca el precio del producto:");

            if (!(Double.TryParse(Console.ReadLine(), out precio)))
            {
                Console.WriteLine("El precio introducido no es correcto.");
            }
            else
            {
                // ABRO, ESCRIBO y CIERRO
                using (StreamWriter escritor = new StreamWriter(ruta, true))
                {
                    escritor.WriteLine(nombre + ";" + precio);
                }// SE CIERRA SOLO
            }
        }
        public static void Ejercicio4()
        {
            Menu();
        }

        public static void Ejercicio5()
        {
            string ruta = "";
            bool adivinada = false;
            string palabra = "";
            int intentos = 1;
            try
            {
                ruta = Path.Join("archivos", "palabras.txt");
                string[] lineas = File.ReadAllLines(ruta);
                int seleccionado = new Random().Next(0, lineas.Length - 1);
                string palabraSeleccionada = lineas[seleccionado];

                while (!adivinada && intentos <= 3)
                {
                    Console.Write($"Introduce la palabra a adivinar - intentos:{intentos}:");
                    palabra = Console.ReadLine();
                    if (palabra == palabraSeleccionada)
                    {
                        adivinada = true;
                        Console.WriteLine("Enhorabuena has acertado la palabra.");
                    }
                    else
                    {
                        intentos++;
                    }
                }
                if (!adivinada)
                {
                    Console.WriteLine($"La palabra secreta era {palabraSeleccionada}");
                }
            }
            catch (FileNotFoundException exp)
            {
                Console.WriteLine("No se encuentra el archivo:" + exp.Message);

            }
            catch (Exception e)
            {
                Console.WriteLine("Se ha producido un error:" + e.Message);
            }

        }
        public static void Ejercicio6()
        {
            string ruta = "";
            bool adivinada = false;
            char letra;
            int intentos = 1;
            string asteriscos = "";
            try
            {
                ruta = Path.Join("archivos", "palabras.txt");
                string[] lineas = File.ReadAllLines(ruta);
                int seleccionado = new Random().Next(0, lineas.Length - 1);
                string palabraSeleccionada = lineas[seleccionado];
                // RELLENAMOS ASTERISCOS
                for (int i = 0; i < palabraSeleccionada.Length; i++)
                {
                    asteriscos = String.Concat(asteriscos, "*");
                }

                //Console.WriteLine(String.Join("", palabraSeleccionada));
                //Console.WriteLine(String.Join("", asteriscos));

                while (!adivinada && intentos <= 7)
                {
                    Console.WriteLine("\n" + String.Join("", asteriscos));
                    int posicionLetra = -1;
                    Console.Write($"\nIntroduce la letra - intentos {intentos}:");
                    letra = Console.ReadKey().KeyChar;
                    if (palabraSeleccionada.Contains(letra))
                    {
                        //REEMPLAZAMOS
                        for (int i = 0; i < palabraSeleccionada.Length; i++)
                        {
                            posicionLetra = palabraSeleccionada.IndexOf(letra, i, palabraSeleccionada.Length - i);
                            if (posicionLetra != -1)
                            {
                                asteriscos = asteriscos.Remove(posicionLetra, 1);
                                asteriscos = asteriscos.Insert(posicionLetra, letra.ToString());
                                i = posicionLetra;
                                //Console.WriteLine(String.Join("", palabraSeleccionada));
                                //Console.WriteLine(String.Join("", asteriscos));
                            }
                            else
                            {
                                break;
                            }
                        }

                    }
                    else
                    {
                        intentos++;
                    }
                    if (palabraSeleccionada == asteriscos)
                    {
                        adivinada = true;
                        Console.WriteLine($"\nEnhorabuena has ganado. {palabraSeleccionada}");
                    }

                }

                if (!adivinada)
                {
                    Console.WriteLine($"\nLa palabra secreta era {palabraSeleccionada}");
                }
            }
            catch (FileNotFoundException exp)
            {
                Console.WriteLine("No se encuentra el archivo:" + exp.Message);

            }
            catch (Exception e)
            {
                Console.WriteLine("Se ha producido un error:" + e.Message);
            }

        }
        public static void Ejercicio8()
        {
            string ruta = "";
            string texto = "";
            Console.Write("Introduce un nombre de fichero que quieras leer:");
            ruta = Console.ReadLine();

            try
            {
                texto = File.ReadAllText(ruta);
                Console.WriteLine(texto);
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine($"No se encuentra el archivo {ruta}\n"+e.Message);
            }
        }

        public static void Ejercicio9()
        {
            string ruta = "";
            //string texto = "";
            Console.Write("Introduce un nombre de fichero que quieras leer:");
            ruta = Console.ReadLine();
            string[] filas;
            try
            {
                filas = File.ReadAllLines(ruta);
                for (int i = filas.Length-1; i >= 0; i--)
                {
                    Console.WriteLine(filas[i]);
                }

            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine($"No se encuentra el archivo {ruta}\n" + e.Message);
            }
        }
        public static void Ejercicio10()
        {

            string ruta = "";
            string linea = "";
            Console.Write("Introduce un nombre de fichero que quieras leer:");
            ruta = Console.ReadLine();
            StreamReader lector;
            int contador = 0;
            try
            {

                lector = new StreamReader(ruta);
                while ((linea = lector.ReadLine()) != null)
                {
                    if (linea.Length > 79)
                    {
                        linea = linea.Substring(0, 79);
                        //Console.WriteLine("RECORTADA");
                    }
                    Console.WriteLine(linea);
                    if (contador>0 && contador %24 == 0)
                    {
                        Console.WriteLine();
                        Console.WriteLine("............ Pulse Enter para continuar ...............");
                        Console.ReadLine();
                    }

                    contador++;
                }
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine($"No se encuentra el archivo {ruta}\n" + e.Message);
            }
        }

        static void Main(string[] args)
        {

            //Explicacion();
            //Ejercicio1();
            //Explicacion2();
            //Ejercicio2();
            //Ejercicio3();
            //Ejercicio4();
            //Menu();
            //Ejercicio5();
            // Ejercicio6();
            // Ejercicio8();
            Ejercicio9();
            //Ejercicio10();
        }
    }
}
