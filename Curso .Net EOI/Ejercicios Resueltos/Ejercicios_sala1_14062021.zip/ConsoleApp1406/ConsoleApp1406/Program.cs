﻿using System;
using System.IO;

namespace ConsoleApp1406
{
    class Program
    {
        public static void EscribirFichero1()
        {
            try
            {
                StreamWriter miFichero = new StreamWriter("textFile1.txt");
                miFichero.WriteLine("Hola");
                miFichero.WriteLine("Adiós");
                miFichero.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error en el fichero: {e.Message}");
            }
        }
        public static void Ejercicio2()
        {
            try
            {
                StreamWriter writer = new StreamWriter("TextEjercicio02.txt");

                for (int i = 0; i < 100; i++)
                {
                    writer.WriteLine($"Linea {i + 1}");
                }
                writer.Close();
            }
            catch (ArgumentNullException)
            {
                Console.WriteLine("Error en el fichero puntero nulo");
            }
            catch (ArgumentException)
            {
                Console.WriteLine("Error en el fichero");
            }
            catch (Exception)
            {
                Console.WriteLine("Excepción");
            }
            
        }
        public static bool EsPrimo(int numero)
        {
            bool esPrimo = true;
            for(int i=2;i<numero && esPrimo;i++)
            {
                if (numero % i == 0)
                    esPrimo = false;
            }
            return esPrimo;
        }
        public static void Primos50()
        {
            int primos = 0;
            StreamWriter miFichero = new StreamWriter("primos.txt");
            /*  for(int i=1;primos<50;i++)
              {
                  if(EsPrimo(i))
                  {
                      primos++;
                      miFichero.Write(i + " ");
                  }
              }
            */
          int numero = 1;
          while(primos<50)
          {
                if (EsPrimo(numero))
                {
                    primos++;
                    miFichero.Write(numero + " ");
                }
                numero++;
          }
          miFichero.Close();
        }
    static void Main(string[] args)
        {
            int[] array=new int[10];
            try
            {
                array[11] = 20;
            }
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Error");
            }
            //EscribirFichero1();
            //Ejercicio2();
            //Primos50();

        }
    }
}
