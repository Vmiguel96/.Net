﻿using System;

namespace Ejercicios4._2_funciones_cadenas
{
    class Program
    {
        public static void Modifica(ref string p)
        {
            p = "MODIFICADO";
        }

        public static void ModificaArray(int[] a)
        {
            a[1] = 100;

        }
        public static int Ejercicio1(params int[] numeros)
        {
            int max = 0;
            if (numeros.Length == 0)
            {
                return 0;
            }
            else
            {
                max = numeros[0];
                for (int i = 1; i < numeros.Length; i++)
                {
                    max = Math.Max(max, numeros[i]);
                }
                return max;
            }
        }

        public static int Ejercicio2(string texto, string abuscar)
        {
            int posicion = 0;
            int veces = 0;
            do
            {
                posicion = texto.IndexOf(abuscar, posicion); // 6 - 1// 16  - 2 // 
                if (posicion != -1)
                {
                    posicion = posicion + abuscar.Length;
                    veces++;
                }
            }
            while (posicion != -1);

            return veces;
        }

        public static string Ejercicio3(string original, char c, int repetir)
        {
            //string modificada = "";
            for (int i = repetir; i < original.Length; i = i + repetir + 1)
            {
                original = original.Insert(i, c.ToString());
            }
            return original;
        }

        public static double Ejercicio4(string notas)
        {
            double media = 0;
            string[] auxiliar = notas.Split(";");
            int cantidadErrores = 0;
            for (int i = 0; i < auxiliar.Length; i++)
            {
                double temp = 0;
                Console.WriteLine($"[{i}]:[{auxiliar[i]}]");
                // media = media + Convert.ToDouble(auxiliar[i]);
                // solucion pro
                if (Double.TryParse(auxiliar[i], out temp))
                {
                    media = media + temp;
                }
                else
                {
                    cantidadErrores++;
                    Console.WriteLine($"Error: No se pudo convertir la nota {auxiliar[i]} en Double");
                }
            }
            media = media / (auxiliar.GetLength(0) - cantidadErrores);
            return media;
        }

        public static string[] Ejercicio5(string[] lista)
        {
            Array.Sort(lista);
            Array.Reverse(lista);
            return lista;
        }

        public static int Ejercicio6(int[] lista, int valor)
        {

            int[] arrayVeces = Array.FindAll(lista, n => n == valor);
            Console.WriteLine(String.Join("*", arrayVeces));
            return arrayVeces.Length;
        }
        public static string Ejercicio7(DateTime fecha)
        {
            string[] dias = { "Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado" };
            string diaHoy = dias[(int)fecha.DayOfWeek];
            return $"La fecha es {diaHoy}, {fecha.Day:D2}/{fecha.Month:D2}/{fecha.Year}";
        }

        public static DateTime Ejercicio8(string fecha)
        {
            string[] partes = fecha.Split("-");
            int dia = Convert.ToInt32(partes[0]);
            int mes = Convert.ToInt32(partes[1]);
            int anyo = Convert.ToInt32(partes[2]);

            DateTime fechaNueva = new DateTime(anyo, mes, dia);

            DateTime fechaFutura =  fechaNueva.AddYears(2).AddMonths(5).AddDays(3);
            
            return fechaFutura;
        }
    
        static void Main(string[] args)
        {
            //int[] n = { 1, 3, 6, 3, 1, 8, 100 };
            //Console.WriteLine($"El número máximo es:{Ejercicio1(n)}");

            //string texto1 = "EL PERRO DE SAN ROQUE NO TIENE COLA RO";
            //string buscar1 = "RO";

            //Console.WriteLine(Ejercicio2(texto1, buscar1));

            //string original = "Hay una mosca en mi sopa";
            //char c = '*';
            //int repetir = 3;
            //Console.WriteLine(Ejercicio3(original, c, repetir));


            //string intercambio = "9,5;8;7;6,66;9,99;10;S";
            //Console.WriteLine($"La media es: {Ejercicio4(intercambio)}");

            //string[] listaPalabras = { "pantalla", "té", "ratón", "monitor", "cartera", "agenda", "cuchara", "gafas" };
            //Console.WriteLine($"{String.Join(", ", Ejercicio5(listaPalabras))}");

            //int[] listaNumeros = { 1, 3, 5, 7, 9, 3, 5, 7, 3, 2, 1, 0 };
            //Console.WriteLine($"El numero de veces que aparece el  3 es:{Ejercicio6(listaNumeros,3)}");

            Console.WriteLine(Ejercicio7(DateTime.Now));
            Console.WriteLine(Ejercicio7(DateTime.Now.AddDays(100)));

            Console.WriteLine(Ejercicio7(Ejercicio8("01-07-2021")));

            //string palabra = "INICIAL";
            //Console.WriteLine($"ANTES:{palabra}");
            //Modifica(ref palabra);
            //Console.WriteLine($"DESPUES:{palabra}");

            //int[] numeros1 = { 1, 2, 3, 4, 5 };
            //for (int i = 0; i < numeros1.Length; i++)
            //    Console.Write($"{numeros1[i] }");
            //Console.WriteLine();
            //ModificaArray(numeros1);

            //for (int i = 0; i < numeros1.Length; i++)
            //    Console.Write($"{numeros1[i]} ");
            //Console.WriteLine();

            //int[] numeros2 = {3,4,5,6,7};
            //numeros2 = numeros1;

            //for (int i = 0; i < numeros2.Length; i++)
            //    Console.Write($"{numeros2[i]} ");
            //Console.WriteLine();

            //numeros2[1] = 99;

            //for (int i = 0; i < numeros1.Length; i++)
            //    Console.Write($"{numeros1[i]} ");
            //Console.WriteLine();

            //int[] numeros3 = new int[numeros1.Length];

            //for (int i = 0; i < numeros1.Length; i++)
            //    numeros3[i] = numeros1[i];
            //numeros3[1] = 2;

            //for (int i = 0; i < numeros1.Length; i++)
            //    Console.Write($"{numeros1[i]} ");
            //Console.WriteLine();

            //for (int i = 0; i < numeros3.Length; i++)
            //    Console.Write($"{numeros3[i]} ");
            //Console.WriteLine();
            //string p1 = "HOLA";
            //string p2 = "QUE TAL";

            //Console.WriteLine(String.Concat(p1," ", p2));
            //double[] notas = { 5.65, 7.85, 6.5, 9 }; 
            //Console.WriteLine($"Mis notas son: {String.Join(", ", notas)}"); //Mis notas son: 5,65, 7,85, 6,5, 9


            //string s1 = "1A"; 
            //string s2 = "1A"; 
            //Console.WriteLine(String.Compare(s1, s2)); // -1

            //string s = "Mi perro se llama Comeniños"; 
            //Console.WriteLine(s.IndexOf("perro")); // 3
            //Console.WriteLine(s.IndexOf("gato"));// -1


            //string s = "Mi perro se llama Comeniños";
            //Console.WriteLine(s);
            //string s1 = s.Remove(3, 5);
            //Console.WriteLine(s1);
            //string s2 = s1.Insert(3, "koala"); 
            //Console.WriteLine(s2); //

            //string s = "Mi perro se llama Comeniños"; 
            //string s1 = s.Replace("perro", "koala"); 
            //Console.WriteLine(s1);

            //string s = "pato, gato, perro, koala"; 
            //string[] animales = s.Split(","); 
            //Console.WriteLine($"Hay {animales.Length} animales.{animales[0]}");

            // DATETIME
            //DateTime fechaHoy = new DateTime(2021, 06, 7, 19, 59, 59);
            //Console.WriteLine(fechaHoy);
            //DateTime fechaAhora = DateTime.Today;
            //Console.WriteLine(fechaAhora);
            //string[] dias = { "Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado" };
            //DateTime fecha = DateTime.Now;
            //string diaHoy = dias[(int)fecha.DayOfWeek];
            //Console.WriteLine($"Hoy es {diaHoy}, {fecha.Day:D2}/{fecha.Month:D2}/{fecha.Year}");
        }
    }
}
