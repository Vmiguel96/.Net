﻿using System;

namespace Calcula
{
    class Program
    {
        static void Main(string[] args)
        {
            // args[0] -- "suma" ,"resta", "multiplica","divide"
            // args[1] número 1 "2"  Convert.ToDouble(args[1])
            // args[2] número 2 "4"
            double numero1;
            double numero2;

            if (args.Length != 3)
            {
                Console.WriteLine("Número de argumentos incorrecto");
            }
            else
            {
                numero1 = Convert.ToDouble(args[1]);
                numero2 = Convert.ToDouble(args[2]);
               switch (args[0])
                {
                    case "suma":
                        Console.WriteLine(numero1 + numero2);
                        break;
                    case "resta":
                        Console.WriteLine(numero1 - numero2);
                        break;
                    case "multiplica":
                        Console.WriteLine(numero1 * numero2);
                        break;
                    case "divide":
                        Console.WriteLine(numero1 / numero2);
                            break;
                    default:
                        Console.WriteLine("Operación incorrecta");
                        break;

                }
            }
                

        }
    }
}
