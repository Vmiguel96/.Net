﻿using System;

namespace ConsoleApp0206
{
    class Program
    {
        public static void Saluda()
        {
            Console.WriteLine("!Hola!");
        }
        public static void Saluda(string nombre)
        {
            Console.WriteLine($"Hola {nombre}");
        }

        public static int Sum(int n1,int n2)
        {
            int resultado = n1 + n2;
            return resultado;
        }

        public static double Media(double n1,double n2,double n3)
        {
            double resultado = (n1 + n2 + n3) / 3;
            return resultado;
        }

        public static void MostrarMedia(double n1,double n2,double n3)
        {
            double media = Media(n1, n2, n3);
            Console.WriteLine($"La media es: {media}");
        }

        public static bool EsAlfabetico(char c)
        {
            /*  bool resultado;
              if(c>='A' && c<='Z')
              {
                  resultado = true;
              }
              else
              {
                  resultado = false;
              }
              return resultado;*/

            return c >= 'A' && c <= 'Z';
                
        }
       

        static void Main(string[] args)
        {
            /*Saluda();
            Saluda("Mari Chelo");
            int resultado=Sum(2, 5);
            double media = Media(3, resultado, 5);
            Console.WriteLine($"La media de 3,4,5 es {media}");*/

            /*Console.WriteLine("Introduzca número 1: ");
            double numero1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Introduzca número 2: ");
            double numero2 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Introduzca número 3: ");
            double numero3 = Convert.ToDouble(Console.ReadLine());

            MostrarMedia(numero1, numero2, numero3);*/

            if(EsAlfabetico('M'))
            {
                Console.WriteLine("Es alfabético");
            }
            

            
        }
    }
}
