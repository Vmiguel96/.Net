﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GestionEmpleados
{
    public class FileUtils
    {
        public static List<Persona> CargaEmpleados()
        {
            List<Persona> empleados = new List<Persona>();
            //abro fichero y leo línea a línea "empleados.txt"
            //lineas --> nombre;edad;dni
            //linea.Split(';') --> string[] trozos
            // crear una Persona
            //añadir a la lista
            //Cerrar fichero

            return empleados;
        }
        public static void GuardaEmpleados(List<Persona> p)
        {
            //recorrer lista uno a uno
            //guardar en fichero con formato adecuado
            //Cerrar fichero
        }
    }
}
