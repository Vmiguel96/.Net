﻿using System;

namespace GestionEmpleados
{
    public class Program
    {

        //Crear clase Empresa :
           // nombre (string) 
           // empleados (Lista de Persona) sólo lectura
           //Constructor recibe nombre de la empresa e inicializa la lista (new)
           //Para probarlo crea una empresa y muestra He creado la empresa "Nombre empresa"

        public static void Menu()
        {
            Console.WriteLine("1.Contratar empleado"); //método ContrataEmpleado
            Console.WriteLine("2.Despedir empleado"); //método DespideEmpleado
            Console.WriteLine("3.Listar empleado");  //método ListaEmpleados
            Console.WriteLine("4.Buscar empleado"); //Find
            Console.WriteLine("5.Existe empleado"); //Contains
            Console.WriteLine("6.Salir");
        }
        public static Persona CreaEmpleado()
        {
            Persona empleado=new Persona();
            Console.WriteLine("Nombre: ");
            empleado.SetNombre(Console.ReadLine());
            Console.WriteLine("Edad: ");
            empleado.Edad = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("DNI: ");
            empleado.Dni = Console.ReadLine();
            return empleado;
        }
        public static void Despedir(Empresa empresa)
        {
            string dato;
            int posicion;
            Console.WriteLine("Introduzca DNI o Enter para pedir posición:");
            dato = Console.ReadLine();
            if(dato=="")
            {
                Console.WriteLine("Introduzca posición");
                posicion = Convert.ToInt32(Console.ReadLine())-1;
                empresa.DespideEmpleado(posicion);
            }
            else
            {
                empresa.DespideEmpleado(dato);
            }
        }
        public static void Buscar(Empresa empresa)
        {
            string nombre;
            Console.WriteLine("Nombre a buscar");
            nombre = Console.ReadLine();
            Console.WriteLine(empresa.Empleados.Find(p => p.GetNombre() == nombre));
        }
        public static void Main(string[] args)
        {
           
            Empresa empresa = new Empresa("Maravillosa Empresa");
            //Pruebas
            /* Console.WriteLine($"He creado la empresa {empresa.Nombre}");
             Persona empleado = new Persona("Empleado1", 23, "111111");
             empresa.ContrataEmpleado(empleado);
             empleado = new Persona("Empleado2", 25, "222222");
             empresa.ContrataEmpleado(empleado);
             empleado = new Persona("Empleado3", 35, "333333");
             empresa.ContrataEmpleado(empleado);
             empleado = new Persona("Empleado4", 55, "444444");
             empresa.ContrataEmpleado(empleado);
             empresa.ListaEmpleados();
             Console.WriteLine("Despido posición 2 (tercero)");
             empresa.DespideEmpleado(2);
             empresa.ListaEmpleados();
             Console.WriteLine("Despido posición dni 444444");
             empresa.DespideEmpleado("444444");
             empresa.ListaEmpleados();*/
            //Menú
            bool salir = false;
            string opcion;
            Persona empleado;
            string dni;
            do
            {
                Menu();
                opcion = Console.ReadLine();
                switch (opcion)
                {
                    case "1":
                        empleado = CreaEmpleado();
                        empresa.ContrataEmpleado(empleado);
                        break;
                    case "2":
                        Despedir(empresa);
                        break;
                    case "3":
                        empresa.ListaEmpleados();
                        break;
                    case "4":
                        Buscar(empresa);
                        break;
                    case "5":
                        Console.WriteLine("Introduzca DNI: ");
                        dni = Console.ReadLine();
                        if (empresa.Empleados.Contains(new Persona("", 0, dni)))
                            Console.WriteLine("Sí existe");
                        else
                            Console.WriteLine("No existe");
                        break;
                    case "6":
                        salir = true;
                        break;
                }

            } while (!salir);
            






        }
    }
}
