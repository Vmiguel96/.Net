﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GestionEmpleados
{
    public class Empresa
    {
        string nombre;
        List<Persona> empleados;

        public string Nombre { get => nombre; set => nombre = value; }
        public List<Persona> Empleados { get => empleados;}

        public Empresa(string nombre)
        {
            this.nombre = nombre;
            this.empleados = new List<Persona>();
        }
        public Empresa():this("")
        {

        }

        public void ContrataEmpleado(Persona p)
        {
            empleados.Add(p);
        }


        public void DespideEmpleado(int posicion)
        {
            empleados.RemoveAt(posicion);
        }

        public void DespideEmpleado(string dni)
        {
            empleados.Remove(new Persona("", 0, dni));
        }

        public void ListaEmpleados()
        {
            foreach (Persona p in empleados)
            {
                Console.WriteLine(p);
            }
        }

        //método ContrataEmpleado --> Add(Persona)
        //2 métodos DespideEmpleado --> RemoveAt(posición) Remove(Persona)
    }
}
