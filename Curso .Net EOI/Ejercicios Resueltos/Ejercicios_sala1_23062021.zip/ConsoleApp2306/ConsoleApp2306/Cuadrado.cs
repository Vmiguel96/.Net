﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2306
{
    public class Cuadrado:Figura
    {
        double lado;

        public double Lado { get => lado; set => lado = value; }

        public override double Perimetro()
        {
            return lado * 4;
        }
        public override double Area()
        {
            return lado * lado;
        }
    }
}
