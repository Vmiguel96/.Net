﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2306
{
    public class Circulo:Figura
    {
        double radio;

        public double Radio { get => radio; set => radio = value; }

        public override double Perimetro()
        {
            return 2 * Math.PI * radio;
        }

        public override double Area()
        {
            return Math.PI * radio * radio;
        }
    }
}
