﻿using System;

namespace ConsoleApp2306
{
    class Program
    {
        static void Main(string[] args)
        {
            Figura[] misFiguras = new Figura[2];
            misFiguras[0] = new Circulo();
            misFiguras[1] = new Cuadrado();
            ((Circulo)misFiguras[0]).Radio = 2;
            ((Cuadrado)misFiguras[1]).Lado = 3;
            for(int i=0;i<misFiguras.Length;i++)
            {
                Console.WriteLine(misFiguras[i].Area());
                Console.WriteLine(misFiguras[i].Perimetro());
            }

          
        }
    }
}
