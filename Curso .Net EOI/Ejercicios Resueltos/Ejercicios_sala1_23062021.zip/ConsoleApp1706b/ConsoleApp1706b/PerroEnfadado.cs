﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1706b
{
    class PerroEnfadado:Perro
    {
        public PerroEnfadado():base()
        {

        }
        public PerroEnfadado(string nombre, string raza):base(nombre,raza)
        {

        }
        public override void Ladrar()
        {
            Console.WriteLine($"{nombre}: Grrrr!");
        }
    }
}
