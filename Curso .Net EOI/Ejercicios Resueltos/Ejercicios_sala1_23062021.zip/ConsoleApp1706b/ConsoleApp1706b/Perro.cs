﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1706b
{
    class Perro
    {
        protected string nombre;
        protected string raza;
        protected int edad;

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }
        public string Raza
        {
            get { return raza; }
            set { raza = value; }
        }

        public int GetEdad()
        {
            return edad;
        }
        public void SetEdad(int edad)
        {
            this.edad = edad * 7;
        }

        public Perro()
        {
            nombre = "";
            raza = "";
        }
        public Perro(string nombre,string raza)
        {
            this.nombre = nombre;
            this.raza = raza;
        }  
        public virtual void Ladrar()
        {
            Console.WriteLine($"{nombre}: ¡Guau!");
        }

        public override bool Equals(object obj)
        {
            if ((obj == null) || !(obj is Perro)) return false;
            Perro p = (Perro)obj;
            return nombre == p.nombre && raza == p.raza;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(nombre, raza);
        }
    }
}
