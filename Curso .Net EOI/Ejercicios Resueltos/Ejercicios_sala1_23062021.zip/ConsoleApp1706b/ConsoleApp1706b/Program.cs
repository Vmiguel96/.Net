﻿using System;

namespace ConsoleApp1706b
{
    class Program
    {
        static void Main(string[] args)
        {
            Perro[] perros = new Perro[2];
            /* for(int i=0;i<perros.Length;i++)
             {
                 perros[i] = new Perro();
             }*/
            perros[0] = new Perro();
            perros[0].Nombre = "Bongo"; //propiedades
            //perros[0].SetNombre("Bongo");
            perros[0].Raza = "Pastor Alemán";
            //perros[0].SetRaza("Pastor Alemán");
            perros[1] = new PerroEnfadado();
            perros[1].Nombre = "Bongo";
            perros[1].Raza = "Pastor Alemán";
           // perros[4].Nombre = "Java";
            //perros[4].SetNombre("Java");
           // perros[4].Raza = "Mastín español";
            //perros[4].SetRaza("Mastín español");
            for(int i=0;i<perros.Length;i++)
            {
                perros[i].Ladrar();
            }

            if (perros[0].Equals(perros[1]))
                Console.WriteLine("Son iguales");
            else
                Console.WriteLine("No son iguales");

        }
    }
}
