﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1706
{
    public class PersonaInglesa:Persona
    {
        
        public override void Saluda()
        {
            Console.WriteLine($"Hello my name is {nombre} and I'm {edad} years old ");
        }

    }
}
