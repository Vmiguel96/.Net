﻿using System;

namespace ConsoleApp0706
{
    class Program
    {
        public static void ApropiadaCadena(ref string cadena)
        {
            
            cadena = cadena.ToLower();
            cadena = Convert.ToString(cadena[0]).ToUpper()+ cadena.Substring(1);
            cadena = cadena.Substring(0, 1).ToUpper() + cadena.Substring(1);

            for(int i=0;i<cadena.Length;i++)
            {
                if (cadena[i] == '.' && i<cadena.Length-1)
                {
                    cadena = cadena.Substring(0, i+1)+cadena.Substring(i+1,1).ToUpper()+
                        cadena.Substring(i+2);
                }
                
                   
            }

            // 1.- Pasar toda la cadena a minúsculas (ToLower())
            // 2.- Primera posición en mayúsculas (ToUpper())
            // recorremos la cadena caracter a caracter con un for
            // si encontramos '.' pasamos a mayúscula la siguiente posición
        }
        
        public static int SumaCifras(int numero)
        {
            int cifrasSumadas=0;
            //Separamos número en cifras.
            //Bucle sacando restos de dividir entre 10
            //Vamos sumando las cifras
            //Devolvemos resultado
            while(numero>0)
            {
                cifrasSumadas += numero % 10;
                numero /= 10;
            }

            return cifrasSumadas;

        }
        public static string EscribirAlReves(string cadena)
        {
            string cadenaAlReves = "";
            for(int i=cadena.Length-1;i>=0;i--)
            {
                cadenaAlReves += cadena[i];
            }
            return cadenaAlReves;
        }
        public static void CuantasVocalesDeCada(string cadena,
                                out int a,
                                out int e,out int i,
                                out int o, out int u)
        {
            a = 0;e = 0;i = 0;o = 0;u = 0;
            for(int j=0;j<cadena.Length;j++)
            {
                switch (cadena[j])
                {
                    case 'a':
                        a++;
                        break;
                    case 'e':
                        e++;
                        break;
                    case 'i':
                        i++;
                        break;
                    case 'o':
                        o++;
                        break;
                    case 'u':
                        u++;
                        break;

                }
            }

            //inicializar los contadores (aeiou)
            //recorrer la cadena caracter a caracter (for)
            //con switch contar las 'a' --> a++;
            //                      'e' --> e++
            //                          ...
        }

        static void Main(string[] args)
        {
            int a, e, i, o, u;
            string cadena = "esta es.la prueba";
            ApropiadaCadena(ref cadena);
            Console.WriteLine(cadena);
            Console.WriteLine(SumaCifras(123));
            Console.WriteLine(EscribirAlReves("Hola!"));
            
            CuantasVocalesDeCada("caenladfsiiiikj", out a, out e,
                                    out i, out o, out u);
            Console.WriteLine(a + " " + e + " " + i + " " + o + " " + u);


        }
    }
}
