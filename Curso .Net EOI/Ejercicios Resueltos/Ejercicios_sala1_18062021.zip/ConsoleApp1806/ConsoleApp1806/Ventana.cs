﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1806
{
    public class Ventana
    {
        int anchura;
        int altura;

        public Ventana(int anchura, int altura)
        {
            this.anchura = anchura;
            this.altura = altura;
        }
        public Ventana()
        {
            anchura = 0;
            altura = 0;
        }

        public int Anchura { get => anchura; set => anchura = value; }
        public int Altura { get => altura; set => altura = value; }

        public void Mostrar()
        {
            Console.WriteLine($"Altura: {altura}, Anchura: {anchura}");
        }
    }
}
