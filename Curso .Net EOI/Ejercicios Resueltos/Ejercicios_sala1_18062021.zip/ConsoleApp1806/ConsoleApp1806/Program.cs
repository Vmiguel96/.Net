﻿using System;

namespace ConsoleApp1806
{
    class Program
    {
        static void Main(string[] args)
        {
            Random r = new Random();
            Ventana[] ventanas = new Ventana[10];
            for(int i=0;i<10;i++)
            {
                ventanas[i] = 
                    new Ventana(r.Next(90, 121), r.Next(40, 101));
            }
            for(int i=0;i<10;i++)
            {
                ventanas[i].Mostrar();
            }


        }
    }
}
