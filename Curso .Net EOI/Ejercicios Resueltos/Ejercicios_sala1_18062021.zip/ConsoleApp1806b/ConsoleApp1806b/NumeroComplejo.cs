﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1806b
{
    public class NumeroComplejo
    {
        double real;
        double imaginaria;

        public double Real { get => real; set => real = value; }
        public double Imaginaria
        {
            get { return imaginaria; }
            set { imaginaria = value; }
        }

        public NumeroComplejo(double real, double imaginaria)
        {
            this.real = real;
            this.imaginaria = imaginaria;
        }

        public NumeroComplejo():this(0,0)
        {       
        }

        public NumeroComplejo(NumeroComplejo n):this(n.real,n.imaginaria)
        {
        }

        public double GetMagnitud()
        {
            //Math.Sqrt(Math.Pow(real, 2) + Math.Pow(imaginaria, 2));
            return Math.Sqrt((real * real) + (imaginaria * imaginaria));        
        }
        public override string ToString()
        {
            string resultado = $"{real}";
            if (imaginaria < 0)
                resultado += $"{imaginaria}i";
            else
                resultado += $"+{imaginaria}i";
            return resultado;
        }

        public static NumeroComplejo Suma(NumeroComplejo n1,NumeroComplejo n2)
        {
            NumeroComplejo resultado = new NumeroComplejo();
            resultado.Real = n1.Real + n2.Real;
            resultado.Imaginaria = n1.Imaginaria + n2.Imaginaria;
            return resultado;
        }
    }
}
