﻿using System;

namespace ConsoleApp1806b
{
    class Program
    {
        static void Main(string[] args)
        {
            NumeroComplejo n = new NumeroComplejo(2,-5);
            NumeroComplejo n2 = new NumeroComplejo(3, 4);
            
            Console.WriteLine(n.GetMagnitud());


            NumeroComplejo n3 = NumeroComplejo.Suma(n, n2);
        }
    }
}
