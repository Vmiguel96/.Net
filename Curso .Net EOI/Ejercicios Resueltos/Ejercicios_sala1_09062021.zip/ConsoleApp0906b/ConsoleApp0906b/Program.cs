﻿using System;

namespace ConsoleApp0906b
{
    class Program
    {

        public static void RellenarArray(string[] nombres)
        {
            for(int i=0;i<10;i++)
            {
                Console.Write("Escriba un nombre: ");
                nombres[i] = Console.ReadLine();
            }
        }

        public static void BuscarNombre(string[] nombres)
        {
            Console.Write("Introduzca nombre a buscar:");
            string nombre = Console.ReadLine();

            for(int i=0;i<nombres.Length;i++)
            {
                if(nombres[i]==nombre)
                {
                    Console.WriteLine($"{i + 1}. {nombres[i]} ");
                }
            }

        }
        public static void BuscarPosteriores(string[] nombres)
        {
            Console.Write("Introduzca texto para ordenar:");
            string nombre = Console.ReadLine();
            for (int i = 0; i < nombres.Length; i++)
            {  
                if (String.Compare(nombres[i],nombre)>0)
                {
                    Console.WriteLine($"{i + 1}. {nombres[i]} ");
                }
            }

        }
        public static void BuscarContenga(string[] nombres)
        {
            Console.Write("Introduzca texto para buscar:");
            string nombre = Console.ReadLine();
            for (int i = 0; i < nombres.Length; i++)
            {
                if (nombres[i].Contains(nombre))
                {
                    Console.WriteLine($"{i + 1}. {nombres[i]} ");
                }
            }

        }
        static void Main(string[] args)
        {
            string opcion;
            bool salir = false;
            string[] nombres = new string[10];

            do
            {
                Console.WriteLine("1.Rellenar Array");
                Console.WriteLine("2.Buscar nombre");
                Console.WriteLine("3.Buscar posteriores");
                Console.WriteLine("4.Buscar nombre que contenga...");
                Console.WriteLine("5.Salir");
                opcion = Console.ReadLine();

                switch(opcion)
                {
                    case "1":
                        RellenarArray(nombres);
                        break;
                    case "2":
                        BuscarNombre(nombres);
                        break;
                    case "3":
                        BuscarPosteriores(nombres);
                        break;
                    case "4":
                        BuscarContenga(nombres);
                        break;
                    case "5":
                        salir = true;
                        break;
                }

            } while (!salir);
        }
    }
}
