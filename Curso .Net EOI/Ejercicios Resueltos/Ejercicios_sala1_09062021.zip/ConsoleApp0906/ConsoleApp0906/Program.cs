﻿using System;

namespace ConsoleApp0906
{
    class Program
    {
        public static string CambiaCadena(string cadena)
        {
            string destino="";

            //Opción 1
          /*  for(int i=0;i<cadena.Length;i++)
            {
                destino += cadena[i];
                if (i < cadena.Length - 1)
                    destino += " ";
            }
          */
            //Opción 2
            for(int i=0;i<cadena.Length-1;i++)
            {
                destino += cadena[i] + " ";
            }
            destino += cadena[cadena.Length - 1];

            return destino;

        }
        public static void FuncionesCadena()
        {
            string cadena;
            string destino;
            string[] cadenas;

            Console.WriteLine("Introduzca cadena:");
            cadena = Console.ReadLine();

            destino = cadena.ToUpper();
            Console.WriteLine($"Mayúsculas: {destino}");

            Console.WriteLine($"Minúsculas: {cadena.ToLower()}");

            Console.WriteLine($"Borradas 2ª y 3º letra: {cadena.Remove(1, 2)}");

            Console.WriteLine($"Insertado yo en la 3ª posición: {cadena.Insert(2, "yo")}");

            Console.WriteLine($"Reemplazasos espacios por _: {cadena.Replace(" ", "_")}");

            Console.WriteLine($"Quitados espacios izquierda: {cadena.TrimStart()}");
            Console.WriteLine($"Quitados espacios derecha: {cadena.TrimEnd()}");

            Console.WriteLine($"Reemplaza las a minúsculas" +
                $" por mayúsculas: {cadena.Replace("a", "A")}");

            cadenas = cadena.Split();
            for (int i = 0; i < cadenas.Length; i++)
            {
                Console.WriteLine(cadenas[i]);
            }

            Console.WriteLine(cadena.Contains("la") ? $"{cadena} contiene 'la'" :
                                                    $"{cadena} no contiene 'la");
        }

            static void Main(string[] args)
        {
            Console.WriteLine(CambiaCadena("Hola"));
            FuncionesCadena();
            
        }
    }
}
