﻿using System;
using System.Threading;

namespace Ejercicios4._1_tardios
{
    class Program
    {
        public static void EscribeTitulo16(string cadena)
        {
            string aux = "";
            //1
            cadena = cadena.ToLower();
            // 2 Intentamos solución IsLetterOrDigit()
            for (int i = 0; i < cadena.Length; i++)
            {
                if (!Char.IsLetterOrDigit(cadena[i]))
                {
                    // QUITAMOS i y PONEMOS I
                    aux = cadena[i + 1].ToString();
                    cadena = cadena.Remove(i+1,1);
                    cadena = cadena.Insert(i+1, aux.ToUpper());
                    cadena = cadena.Remove(i,1);
                    //Console.WriteLine($"{aux}-{i}-{cadena}");
                    i--;
                }
              
            }
            Console.WriteLine($"La cadena final:{cadena}");

        }

        public static bool EsNumeroHarshad17(int numero)
        {
            string numeroLetra= numero.ToString();
            int suma = 0;
            for (int i =0; i<numeroLetra.Length;i++)
            {
                suma += Convert.ToInt32(numeroLetra[i]);
            }

            if (numero % suma == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static void CuentaParImpar18(int numero, out int pares, out int impares)
        {
            pares = 0;
            impares = 0;
            string numeroLetra = numero.ToString();
            for (int i = 0; i < numeroLetra.Length; i++)
            {
                if (Convert.ToInt32(numeroLetra[i]) % 2 == 0)
                { pares++; }
                else
                { impares++; }
            }
        }
        public static void Reloj19()
        {
            for (int i =0;i<5;)
            {
                Console.Clear();
                Console.WriteLine($"{ DateTime.Now.Hour:D2}*{DateTime.Now.Minute:D2}*{DateTime.Now.Second:D2}");
                Thread.Sleep(1000);
            }
         }

        public static void Cumpleaños2021()
        {
            //string dateString = "";
            //Console.WriteLine("DD/MM/AAAA");
            //dateString = Console.ReadLine();
            var date1 = new DateTime(2021, 6, 1, 12, 32, 30);
            foreach (var dateString in date1.GetDateTimeFormats())
            {
                DateTime parsedDate;
                if (DateTime.TryParse(dateString, out parsedDate))
                    Console.WriteLine($"{dateString,-37} {DateTime.Parse(dateString),-19}");
                else
                    Console.WriteLine($"Error al convetir a fecha:{dateString}");
            }
        }


        static void Main(string[] args)
        {
            System.Threading.Thread.CurrentThread.CurrentCulture =
    System.Globalization.CultureInfo.CreateSpecificCulture("es-ES");

            EscribeTitulo16("hola.que tal,,estAs");
            if (EsNumeroHarshad17(121))
                Console.WriteLine("Sí es número Harshad 152");
            else
                Console.WriteLine("No es número Harshad");

            int a = 1234567;
            int b = 0;
            int c = 300;
            CuentaParImpar18(a, out b, out c);
            Console.WriteLine($"{a}-{b}-{c}");
            // Reloj19();
            Cumpleaños2021();
        }
    }
}
