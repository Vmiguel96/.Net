﻿using System;

namespace Ejercicios3._1_arrays
{
    class Program
    {

        public static void Ejercicio1()
        {
            string[] meses = {"Enero", "Febrero","Marzo","Abril", "Mayo", "Junio", "Julio", "Agosto", 
                "Septiembre", "Octubre","Novimebre", "Diciembre"};
            int numero = 0;
            Console.Write("Introduce un número para saber el mes:");
            numero = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine($"El mes elegido es {meses[numero-1]}");
        }

        public static void Ejercicio2()
        {
            int[] numeros = new int[10];

            for (int i = 0; i < numeros.Length; i++)
            {
                Console.Write($"Introduce el número {i + 1}:");
                numeros[i] = Convert.ToInt32(Console.ReadLine());
            }
            //a)
            for (int i = 0; i < numeros.Length; i++)
            {
                Console.Write($"{numeros[i]} ");
            }
            Console.Write("\n");
            //b
            int suma = 0;
            for (int i = 0; i < numeros.Length; i++)
            {
                suma = suma + numeros[i];
            }
            Console.WriteLine($"La suma de los número es:{suma}");

            //c
            double media = 0;
            media = suma / (double) numeros.Length;
            Console.WriteLine($"La media de los número es: {media}");

            //d
            int max = numeros[0];
            int min = numeros[0];
            for (int i = 0; i < numeros.Length; i++)
            {
                if (numeros[i] > max)
                {
                    max = numeros[i];
                }

                if (numeros[i] < min)
                {
                    min = numeros[i];
                }
            }
            Console.WriteLine($"El número mayor es {max} y el menor es {min}");
        }

        public static void Ejercicio3()
        {
            double[] numeros = new double[10];
            for (int i = 0; i < numeros.Length; i++)
            {
                Console.Write($"Introduce un número decimal [{i+1}]:");
                numeros[i] = Convert.ToDouble(Console.ReadLine());
            }
            double suma = 0;
            for (int i = 0; i < numeros.Length; i++)
            {
                suma = suma + numeros[i]; 
            }
            double media = suma / numeros.Length;

            Console.WriteLine($"La media es {media:F2}");

            foreach (double numero in numeros)
            {
                if (numero > media)
                {
                    Console.WriteLine($"{numero}");
                }
            }
        
        }
        static void Main(string[] args)
        {
            //// EXPLICACIÓN DEL TEMA
            //string[] palabras;
            //double[] decimales;

            //int[] numeros = new int[5];
            ////...
            //numeros[0] = 12;
            ////..
            //numeros[1] = 23;
            //numeros[2] = 53;
            //numeros[3] = 5;
            //numeros[4] = 92;

            //int[] numeros2 = { 12, 23, 53, 5, 92 };
            //Console.WriteLine($"Length = {numeros2.Length}");
            //for (int i =0; i< numeros.Length;i++)
            //{
            //    Console.WriteLine($"En la posición {i} esta el valor {numeros[i]}");
            //}

            //foreach (int num in numeros)
            //{
            //    Console.WriteLine($"el valor {num}");
            //}

            //  Ejercicio1();
            //Ejercicio2();
            Ejercicio3();


        }
    }
}
