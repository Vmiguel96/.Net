﻿using System;

namespace Ejercicios3._1_arrays
{
    class Program
    {

        public static void Ejercicio1()
        {
            string[] meses = {"Enero", "Febrero","Marzo","Abril", "Mayo", "Junio", "Julio", "Agosto", 
                "Septiembre", "Octubre","Novimebre", "Diciembre"};
            int numero = 0;
            Console.Write("Introduce un número para saber el mes:");
            numero = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine($"El mes elegido es {meses[numero-1]}");
        }

        public static void Ejercicio2()
        {
            int[] numeros = new int[10];

            for (int i = 0; i < numeros.Length; i++)
            {
                Console.Write($"Introduce el número {i + 1}:");
                numeros[i] = Convert.ToInt32(Console.ReadLine());
            }
            //a)
            for (int i = 0; i < numeros.Length; i++)
            {
                Console.Write($"{numeros[i]} ");
            }
            Console.Write("\n");
            //b
            int suma = 0;
            for (int i = 0; i < numeros.Length; i++)
            {
                suma = suma + numeros[i];
            }
            Console.WriteLine($"La suma de los número es:{suma}");

            //c
            double media = 0;
            media = suma / (double) numeros.Length;
            Console.WriteLine($"La media de los número es: {media}");

            //d
            int max = numeros[0];
            int min = numeros[0];
            for (int i = 0; i < numeros.Length; i++)
            {
                if (numeros[i] > max)
                {
                    max = numeros[i];
                }

                if (numeros[i] < min)
                {
                    min = numeros[i];
                }
            }
            Console.WriteLine($"El número mayor es {max} y el menor es {min}");
        }

        public static void Ejercicio3()
        {
            double[] numeros = new double[10];
            for (int i = 0; i < numeros.Length; i++)
            {
                Console.Write($"Introduce un número decimal [{i+1}]:");
                numeros[i] = Convert.ToDouble(Console.ReadLine());
            }
            double suma = 0;
            for (int i = 0; i < numeros.Length; i++)
            {
                suma = suma + numeros[i]; 
            }
            double media = suma / numeros.Length;

            Console.WriteLine($"La media es {media:F2}");

            foreach (double numero in numeros)
            {
                if (numero > media)
                {
                    Console.WriteLine($"{numero}");
                }
            }
        
        }

        public static void Ejercicio4()
        {
            int[] dias = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
            string[] meses = {"Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agostos","Septiembre",
            "Octubre", "Noviembre", "Diciembre"};
            int mes = 0;
            int dia = 0;
            int totalDias = 0;
            string mesletra = "";
            bool encontrado = false;

            Console.Write("Introduce el mes:");
            //mes = Convert.ToInt32(Console.ReadLine());
            mesletra = Console.ReadLine();
            Console.Write("Introduce el día:");
            dia = Convert.ToInt32(Console.ReadLine());
            int poscionMes = 0;
            int mesEncontrado = 0;
            
            
            // BUSCAMOS EL MES INTRODUCIDO CON LETRA
            for ( poscionMes = 0; poscionMes < meses.Length && encontrado == false; poscionMes++)
            {
                if (mesletra == meses[poscionMes])
                {
                    encontrado = true;
                    mesEncontrado = poscionMes;
                }
            }

            // poscionMes -1 tengo la posición del mes buscado.

            for (int i =0; i< mesEncontrado; i++)
            {
                totalDias = totalDias + dias[i];
            }
            totalDias = totalDias + dia;

            Console.WriteLine($"El {dia} de {meses[mesEncontrado]} es el día {totalDias} del año.");

        }

        public static void Ejercicio5()
        {
            int tam = 0;
            Console.Write("Número de alumos a introducir:");
            tam = Convert.ToInt32(Console.ReadLine());

            double[] notas = new double[tam];
            string[] nombres = new string[tam];

            // FOR PARA INTRODUCIR LOS NOMBRES Y LAS NOTAS
            for(int i = 0;i<tam; i++) // también podría ser i<nota.Lenght
            {
                Console.Write($"Introduce el nombre del alumno [{i+1}]");
                nombres[i] = Console.ReadLine();
                Console.Write($"Introduce la nota del alumno [{i + 1}]");
                notas[i] = Convert.ToDouble(Console.ReadLine());
            }

            string nombreAlumno="";
            // PEDIMOS UN NOMBRE y MOSTRAMOS SU NOTA
            Console.WriteLine("------------------------------------------------------------------");
            Console.Write("Introduce el nombre del alumno del que quieras saber la nota:");
            nombreAlumno= Console.ReadLine();

            bool encontrado = false;
            int posicionEncontrado = 0;
            for (int i = 0; i < tam && encontrado == false; i++)
            {
                if (nombreAlumno == nombres[i])
                {
                    encontrado = true;
                    posicionEncontrado = i;
                }
            }

            Console.WriteLine($"El alumno {nombres[posicionEncontrado]} " +
                                $"tiene una nota de {notas[posicionEncontrado]}");

            // HACEMOS LO QUE DICE EL ENUNCIADO DE MOSTRAR TODOS LOS NOMBRES Y SU NOTA.
            Console.WriteLine("------------------------------------------------------------------");
            for (int i = 0; i < nombres.Length; i++)
            {
                Console.WriteLine($"{nombres[i]} - {notas[i]:F2}");
            }

        }

        public static void Ejercicio6()
        {
            int[] tablaMultiplicar = new int[10];
            int numero = 0;
            Console.Write("Introduce un número:");
            numero = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < tablaMultiplicar.Length; i++)
            {
                tablaMultiplicar[i] = i+1 * numero;
            }

            // SON EQUIVALENTES

            for (int i = 1; i <= tablaMultiplicar.Length; i++)
            {
                tablaMultiplicar[i-1] = i  * numero;
            }

            for (int j = 0; j<tablaMultiplicar.Length;j++)
            {
                Console.WriteLine($"{numero} x {j+1} = {tablaMultiplicar[j]}");
            }

        }
        public static void Ejercicio7()
        {
            int[] num1 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            int[] num2 = { 23, 63, 89, 77, 44, 12, 1, 0, 9, 100 };
            int[] num3 = new int[10];
            //int[] num3 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

            for (int k = 0; k < num1.Length; k++)
            {
                num3[k] = num1[k] + num2[k];
            }

            for (int l = 0; l < num3.Length; l++)
                Console.WriteLine($"La suma[{l}] es {num3[l]}");
        }
        public static void Ejercicio8()
        {
            const int LONGITUD_PASSWORD = 8;
            char[] password = new char[LONGITUD_PASSWORD];
            char[] reverse = new char[LONGITUD_PASSWORD];
            string cadenaVacia = "";

            Console.Write($"Escribe tu contraseña de {LONGITUD_PASSWORD} caracteres:");
            for (int i = 0; i < password.Length; i++)
            {
                password[i] = Console.ReadKey(true).KeyChar;
            }
            
            for(int i = LONGITUD_PASSWORD - 1; i>=0;i--)
            {
             reverse[(LONGITUD_PASSWORD - 1) -i] = password[i];
            }
            Console.Write("\nLa contaseña invertida es:");
            
            for (int i = 0; i < reverse.Length; i++)
            { 
                Console.Write($"{reverse[i]}");
            }

            // SOLUCION PRO
            for (int i = password.Length - 1; i >= 0; i--)
            {
                cadenaVacia = cadenaVacia + password[i];
            }
            Console.WriteLine($"\nEl password invertodo es {cadenaVacia}");
        }
        public static void Ahoracado()
        {
            string[] palabras = { "programa", "vector", "ordenar", "pantalla", "raton", "monitor", "bicicleta", "calendario" };
            int adivina = 0;
            string palabraSecreta = "";
            string palabraArsterisco = "";
            string letra="";
            string palabrasSustitucion = "";
            string resolver = "N";
            string palabraResolver = "";
            bool ganador = false;
            int intentosFallidos = 0;
            bool intentoAcertado = false;
           
           //Selecciona de manera aleatoria una palabra de la lista
           adivina = new Random().Next() % palabras.Length;
           palabraSecreta = palabras[adivina];

            // Genero una array de la misma longitud que palabraSecreta pero con *
            for (int i = 0; i < palabraSecreta.Length; i++)
            {
                palabraArsterisco = palabraArsterisco + "*";
            }
            // Console.WriteLine($"{palabraSecreta} - {palabraArsterisco}");

            // COMIENZA EL JUEGO
            do
            {
                Console.Clear();
                Console.WriteLine("-------------------------------------------");
                Console.WriteLine("-           JUEGO DEL AHORCADO            -");
                Console.WriteLine("-------------------------------------------");
                Console.WriteLine($"La palabra a adivinar es {palabraArsterisco}");
                Console.Write("Introduce una letra:");
                letra = Console.ReadLine();
                intentoAcertado = false;
                // BUSCAR LA LETRA EN LA PALABRA SECRETA.
                for (int i =0; i<palabraSecreta.Length;i++)
                {
                    if (palabraSecreta[i] == letra[0])
                    {
                        intentoAcertado = true;
                        // SECRETO, LA CLAVE
                        //palabraArsterisco[i] = letra[0];
                        // REALIZO LA SUSTITUCION DEL ARTERISCO POR LA LETRA
                        for (int j = 0; j< palabraArsterisco.Length; j++)
                        {
                            if (i == j)
                            {
                                palabrasSustitucion = palabrasSustitucion + letra[0];
                            }
                            else
                            {
                                palabrasSustitucion = palabrasSustitucion + palabraArsterisco[j];
                            }
                        }
                        palabraArsterisco = palabrasSustitucion;
                        palabrasSustitucion = "";
                    }

                }

                // GESTIONAMOS QUE NO HEMOS ACERTADO
                if (intentoAcertado == false)
                {
                    intentosFallidos++;
                    Console.WriteLine($"La letra {letra} no está en la palabra secreta. LLevas {intentosFallidos} intentos"); 
                }
                else 
                {
                    Console.WriteLine($"La letra {letra} está en la palabra secreta");
                }
                Console.WriteLine($"La palabra a adivinar es {palabraArsterisco}");
                
                // PEDIR LA RESOLUCION
                Console.Write("¿Quieres resolver [S|N]?");
                resolver = Console.ReadLine();
                
                if (resolver == "S" || resolver == "s")
                {
                    Console.Write("¿Cúal es la respuesta?");
                    palabraResolver = Console.ReadLine();
                    if (palabraSecreta == palabraResolver) // HAS GANADO Y TERMINA EL JUEGO
                    {
                        ganador = true;
                        Console.WriteLine($"Enhorabuena has adivinado la palabra secreta {palabraSecreta}");
                    }
                }
                // GESTIONAMOS QUE HAS PERDIDO EL JUEGO
                if (intentosFallidos >= 7)
                {
                   Console.WriteLine($"Game Over la palabra secreta era {palabraSecreta}");
                }

            } while (!ganador && intentosFallidos < 7);

        }
        static void Main(string[] args)
        {
            //// EXPLICACIÓN DEL TEMA
            //string[] palabras;
            //double[] decimales;

            //int[] numeros = new int[5];
            ////...
            //numeros[0] = 12;
            ////..
            //numeros[1] = 23;
            //numeros[2] = 53;
            //numeros[3] = 5;
            //numeros[4] = 92;

            //int[] numeros2 = { 12, 23, 53, 5, 92 };
            //Console.WriteLine($"Length = {numeros2.Length}");
            //for (int i =0; i< numeros.Length;i++)
            //{
            //    Console.WriteLine($"En la posición {i} esta el valor {numeros[i]}");
            //}

            //foreach (int num in numeros)
            //{
            //    Console.WriteLine($"el valor {num}");
            //}

            // Recorrer un cadena como si fuera una array de caracteres
            //string texto = "EMOS SIO ENGAÑAOS";
            //for (int i = 0; i < texto.Length; i++)
            //{
            //    Console.WriteLine($"[{i}]:{texto[i]}");
            //}

            //Ejercicio1();
            //Ejercicio2();
            //Ejercicio3();
            //Ejercicio4();
            //Ejercicio5();
            //Ejercicio6();
            //Ejercicio7();
            //Ejercicio8();
            Ahoracado();


        }
    }
}
