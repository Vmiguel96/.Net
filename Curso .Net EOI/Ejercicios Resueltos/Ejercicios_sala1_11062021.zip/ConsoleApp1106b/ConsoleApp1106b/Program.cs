﻿using System;

namespace ConsoleApp1106b
{
    class Program
    {
        public static bool CaracterCorrecto(char c)
        {
            bool correcto = true;
            string especiales = "!#$%&'*+-/=?^_`{|}~;";
            if (!((c>='A' && c<='Z') || (c >= 'a' && c <= 'z')))
            {
                if(!(c>='0' && c<='9'))
                {
                    if(!(especiales.IndexOf(c)>=0))
                    {
                        correcto = false;
                    }
                }
            }
            return correcto;
        }
        static void Main(string[] args)
        {
            string cadena = "aA2!@ji.oj";
            bool correcto = true;
            for(int i=0;i<cadena.Length && correcto ;i++)
            {
                if (!(cadena[i] == '@') && !(cadena[i]=='.'))
                {
                    if (!CaracterCorrecto(cadena[i]))
                        correcto = false;
                }
            }
            if(cadena[0]=='.' || cadena[cadena.Length-1]=='.')
            {
                correcto = false;
            }
            if (cadena.IndexOf("@") >= 0)
            {
                if (!(cadena.IndexOf("@") == cadena.LastIndexOf("@")))
                {
                    correcto = false;
                }
            }
            else
            {
                correcto = false;
            }
            if (cadena.IndexOf(".") >= 0)
            {
                if (!(cadena.IndexOf(".") == cadena.LastIndexOf(".")))
                {
                    correcto = false;
                }
            }
            else
            {
                correcto = false;
            }
            Console.WriteLine(correcto ? "Email válido" : "Email no válido");
        }
    }
}
