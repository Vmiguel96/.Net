﻿using System;

namespace ConsoleApp1106
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //Pedir al usuario lista de películas separadas por guión
            //Separar las películas con split

            string cadena;
            string[] peliculas;
            string[] palabras;
            string temporal;
            Console.Write("Introduzca películas:");
            cadena = Console.ReadLine();
            peliculas = cadena.Split('-');

            for(int i=0;i<peliculas.Length;i++)
            {
                palabras = peliculas[i].Split();
                //Comprobar si la primera palabra es un articulo
                // si es articulo, se pasa al final y con una como ,La
                //Unirla y pasarla a mayúsculas
                if(palabras[0].ToUpper()=="LA" ||
                    palabras[0].ToUpper() == "EL" ||
                    palabras[0].ToUpper() == "LOS" ||
                    palabras[0].ToUpper() == "LAS")
                {
                    temporal = "";
                    for(int j=1;j<palabras.Length;j++)
                    {
                        temporal += palabras[j]+" ";
                    }
                    temporal = temporal.TrimEnd();
                    temporal += ", " + palabras[0];
                    peliculas[i] = temporal;
                }
                peliculas[i] = peliculas[i].ToUpper();
            }
            //Ordenar el array y sacarlo por pantalla
            // Así:  1. AVATAR
            //       2. HISTORIA INTERMINABLE, LA
            //        ...
            Array.Sort(peliculas);

            for(int i=0;i<peliculas.Length;i++)
            {
                Console.WriteLine($"{i+1}. {peliculas[i]}");
            }




        }
    }
}
