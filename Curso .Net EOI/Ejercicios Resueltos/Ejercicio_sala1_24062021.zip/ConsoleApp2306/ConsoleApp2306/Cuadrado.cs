﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2306
{
    public class Cuadrado:IFigura
    {
        double lado;

        public double Lado { get => lado; set => lado = value; }

        public double Perimetro()
        {
            return lado * 4;
        }
        public double Area()
        {
            return lado * lado;
        }
    }
}
