﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2306
{
    public class Circulo:FGeometrica,IFigura
    {
        double radio;

        public double Radio { get => radio; set => radio = value; }

        public  double Perimetro()
        {
            return 2 * Math.PI * radio;
        }

        public  double Area()
        {
            return Math.PI * radio * radio;
        }

        public override void Dibujar()
        {
            Console.WriteLine("Soy un círculo");
        }
    }
}
