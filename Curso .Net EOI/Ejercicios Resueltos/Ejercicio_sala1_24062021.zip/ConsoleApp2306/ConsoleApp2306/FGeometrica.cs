﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2306
{
    public abstract class FGeometrica
    {
        int x;
        int y;

        public abstract void Dibujar();
    }
}
