﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2306
{
    public abstract class Figura
    {
       
        public abstract double Perimetro();
        public abstract double Area();
    }
}
