﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2306
{
    interface IFigura
    {
        double Perimetro();
        double Area();
    }
}
