﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Museo
{
    public class Pintura:Obra
    {
        public Pintura(Autor autor, string propietario, string nombre, int year)
                        :base(autor,propietario,nombre,year)
        {

        }
        public Pintura():this(new Autor(),"","",0)
        {
        }
    }
}
