﻿using System;
using System.Collections.Generic;

namespace Museo
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Autor autor = new Autor("autor1");

            List<Obra> obras = new List<Obra>();
            obras.Add(new Pintura(autor,"pro","obra1",2000));
            obras.Add(new Escultura(autor,"aa","obra2",2000,"mármol"));
            
            foreach(Obra o in obras)
            {
                Console.WriteLine(o);
            }
            obras.Sort();
            foreach (Obra o in obras)
            {
                Console.WriteLine(o);
            }




            //Pedir datos para 10 obras y rellenar el array
            //Preguntar si es Pintura o Escultura y pedir datos según sea
            //Recorrer el array y mostrar los datos
            //El usuario nos proporciona el nombre del autor
            //--> tenemos que crear Objeto Autor para poner en el constructor de Pintura o ES
        }
    }
}
