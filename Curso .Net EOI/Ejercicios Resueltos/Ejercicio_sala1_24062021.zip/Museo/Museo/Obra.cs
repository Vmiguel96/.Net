﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Museo
{
    public class Obra:IComparable<Obra>
    { // Equals -->  2 obras serán iguales cuando tengan el mismo nombre
        // y el mismo propietario

        //IComparable<Obra> --> ordenan por year

        protected Autor autor;
        protected string propietario;
        protected string nombre;
        protected int year;

        public Autor Autor { get => autor; set => autor = value; }
        public string Propietario { get => propietario; set => propietario = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public int Year { get => year; set => year = value; }

        public Obra(Autor autor, string propietario, string nombre, int year)
        {
            this.autor = autor;
            this.propietario = propietario;
            this.nombre = nombre;
            this.year = year;
        }

        public Obra():this(new Autor(),"","",0)
        {

        }

        public override string ToString()
        {
            return $"Nombre: {nombre}  {autor.ToString()}";
        }

        public override bool Equals(object obj)
        {
            if ((obj == null) || !(obj is Obra)) return false;
            return nombre == ((Obra)obj).nombre &&
                   propietario == ((Obra)obj).propietario;
                    
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(propietario, nombre);
        }

        
        public int CompareTo(Obra o)
        {
            if (year == o.year)
            {
                return propietario.CompareTo(o.propietario);

            }
            else
                return year.CompareTo(year);
        }
    }
}
