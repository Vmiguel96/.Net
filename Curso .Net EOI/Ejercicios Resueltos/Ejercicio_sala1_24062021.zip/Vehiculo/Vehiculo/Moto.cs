﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehiculo
{
    public class Moto:Vehiculo
    {
        public Moto(string marca, string modelo, 
            int potencia, int peso, 
            string color):base( marca,  modelo,
                 potencia,  2,  peso,  color)
        { }

        public override void Frenar()
        {
            Console.WriteLine("Moto frenando");
        }

        public override void Acelerar()
        {
            Console.WriteLine("Moto acelerando");
        }
    }
}
