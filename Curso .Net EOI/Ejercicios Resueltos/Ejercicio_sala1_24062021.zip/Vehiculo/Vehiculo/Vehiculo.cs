﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehiculo
{
    public abstract class Vehiculo:IComparable<Vehiculo>
    {
        protected string marca;
        protected string modelo;
        protected int potencia;
        protected int ruedas;
        protected int peso;
        protected string color;

        protected Vehiculo(string marca, string modelo, 
            int potencia, int ruedas, int peso, string color)
        {
            this.marca = marca;
            this.modelo = modelo;
            this.potencia = potencia;
            this.ruedas = ruedas;
            this.peso = peso;
            this.color = color;
        }

        public string Modelo { get => modelo; set => modelo = value; }
        public int Potencia { get => potencia; set => potencia = value; }
        public int Ruedas { get => ruedas; set => ruedas = value; }
        public int Peso { get => peso; set => peso = value; }
        public string Color { get => color; set => color = value; }
        public string Marca { get => marca; set => marca = value; }

        public override string ToString()
        {
            return marca + " " + modelo + " " + potencia + " " + color;
        }

        public abstract void Frenar();
        public abstract void Acelerar();

        public override bool Equals(object obj)
        {
            if((obj==null) || !(obj is Vehiculo)) return false;
            return marca == ((Vehiculo)obj).marca &&
                   modelo == ((Vehiculo)obj).modelo;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(marca, modelo, Color, Marca);
        }

        public int CompareTo(Vehiculo v)
        {
            return marca.CompareTo(v.marca);
        }
     
    }
}
