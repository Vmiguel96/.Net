﻿using System;
using System.Collections.Generic;

namespace Vehiculo
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Vehiculo[] misVehiculos = new Vehiculo[3];
            misVehiculos[0] = new Coche("marca", "modelo", 1000, 1000, "rojo", 5);
            misVehiculos[1] = new Moto("marca2", "modelo2", 1000, 1000, "azul");
            misVehiculos[2] = new Camion("marca3", "modelo3", 1000, 12, 1000, "verde");
*/
            List<Vehiculo> vehiculos = new List<Vehiculo>();
            vehiculos.Add(new Coche("marca", "modelo", 1000, 1000, "rojo", 5));
            Console.WriteLine(vehiculos.Count);
            vehiculos.Add(new Moto("Alfa", "modelo2", 1000, 1000, "azul"));
            Console.WriteLine(vehiculos.Count);
            foreach(Vehiculo v in vehiculos)
            {
                v.Acelerar();
                Console.WriteLine(v);
             
            }
            vehiculos.Sort();
            foreach (Vehiculo v in vehiculos)
            {
                v.Acelerar();
                Console.WriteLine(v);

            }
           /* if (vehiculos.Contains(new Moto("marca2", "modelo2", 1000, 1000, "azul")))
                Console.WriteLine("Sí está");
            else
                Console.WriteLine("no está");*/
            /*for (int i=0;i<vehiculos.Count;i++)
            {
                vehiculos[i].Acelerar();
                Console.WriteLine(vehiculos[i]);
            }*/
            
        }
    }
}
