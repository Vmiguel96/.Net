﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehiculo
{
    public class Camion:Vehiculo
    {
        public Camion(string marca, string modelo, int potencia,
            int ruedas, int peso, string color):base( marca,  modelo, 
                potencia,ruedas,  peso,  color)
        { }

        public override void Frenar()
        {
            Console.WriteLine("Camión frenando");
        }

        public override void Acelerar()
        {
            Console.WriteLine("Camión acelerando");
        }
    }
}
